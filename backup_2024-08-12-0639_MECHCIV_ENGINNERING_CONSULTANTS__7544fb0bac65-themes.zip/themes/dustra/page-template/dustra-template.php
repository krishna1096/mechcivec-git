<?php
 /**
 * Template Name: Dustra Templates
 *
 * The template file for displaying breadcumb with page.
 *
 * @package Dustra
 */
 
  get_header();
  dustra_breadcumb(); 
?>
<div class="page-content">
    <div class="container">
            <?php
            if( have_posts() ):
                while(  have_posts() ): the_post();
                    get_template_part('template-parts/content','page');
                endwhile;
                if( comments_open() || get_comments_number() ):
                    comments_template();
                endif;
                else:
                get_template_part('template-parts/content', 'none');
            endif; 
            ?>
    </div>
</div>
<?php get_footer(); ?>