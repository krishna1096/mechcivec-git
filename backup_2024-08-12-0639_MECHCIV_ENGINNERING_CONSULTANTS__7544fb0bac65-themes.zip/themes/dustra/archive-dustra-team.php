<?php
/**
 * The template for displaying archive for all team
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dustra
 */

  get_header();
  dustra_breadcumb(); 
?>
<!-- Start Team Area 
    ============================================= -->
    <div class="team-area default-padding bottom-less">
        <div class="container">
            <div class="team-items text-center">
                <div class="row">

                        <?php 
                        $teams = array(
                           'post_type'         => 'dustra-team',
                        );
                        $teams = new WP_Query( $teams );
                        if( $teams->have_posts() ):
                            while( $teams->have_posts() ):
                                $teams->the_post();
                        $designation = get_post_meta( get_the_ID(), '_designation', true );
                        $facebook = get_post_meta( get_the_ID(), '_facebook', true );
                        $twitter = get_post_meta( get_the_ID(), '_twitter', true );
                        $youtube = get_post_meta( get_the_ID(), '_youtube', true ); 
                        ?>
                        <!-- Single Item -->
                        <div class="col-lg-4 col-md-6 single-item">
                            <div class="item">
                                <div class="thumb">
                                    <?php if( has_post_thumbnail() ){ ?>
                                        <div class="thumb">
                                            <?php the_post_thumbnail(); ?>
                                        </div>
                                    <?php } ?>
                                    <div class="info">
                                        <a href="<?php echo get_the_permalink();?>"><h4><?php echo esc_html(get_the_title()); ?></h4></a>
                                        <span><?php echo esc_html($designation); ?></span>
                                    </div>
                                    <div class="overlay text-light">
                                        <a href="<?php echo get_the_permalink();?>"><h4><?php echo esc_html(get_the_title()); ?></h4></a>
                                        <p><?php echo esc_html(wp_trim_words(get_the_content(),'22','')); ?></p>
                                        <ul>                                            <li class="facebook">
                                                <a href="<?php echo esc_url($facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                                            </li>
                                            <li class="twitter">
                                                <a href="<?php echo esc_url($twitter); ?>"><i class="fab fa-twitter"></i></a>
                                            </li>
                                            <li class="youtube">
                                                <a href="<?php echo esc_url($youtube); ?>"><i class="fab fa-youtube"></i></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Item -->
                        <?php 
                            
                            endwhile;
                            wp_reset_postdata();
                            endif;
                        ?> 
                    </div>
            </div>
        </div>
    </div>
    <!-- End Team Area -->
<?php get_footer(); ?>  