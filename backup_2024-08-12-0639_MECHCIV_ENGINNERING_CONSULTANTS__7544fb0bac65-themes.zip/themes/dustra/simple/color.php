<?php 
if( class_exists( 'ReduxFrameworkPlugin' ) ) { 
  global $dustra_option; 

function dustra_customize_css() { 
    global $dustra_option; if ($dustra_option['main_color_dustra'] == 2) { 
?>
	<style>
	:root {
  --default-color: <?php echo esc_html($dustra_option['colorcode']); ?>;
  --sec-color: <?php echo esc_html($dustra_option['sec_colorcode']); ?>;
  --topbar-color: <?php echo esc_html($dustra_option['topbar_colorcode']); ?>;
  --footer-color: <?php echo esc_html($dustra_option['footer_colorcode']); ?>;
  }
  

.video-btn i {
  display: inline-block;
  height: 55px;
  width: 55px;
  text-align: center;
  line-height: 55px;
  background: var(--default-color);
  border-radius: 50%;
  position: relative;
  margin-right: 20px;
  color: #ffffff;
}



.text-light .video-btn i {
  background: #ffffff;
  color: var(--default-color);
}



.video-btn i::after {
  content: "";
  position: absolute;
  z-index: 0;
  left: 50%;
  top: 50%;
  -webkit-transform: translateX(-50%) translateY(-50%);
  transform: translateX(-50%) translateY(-50%);
  display: block;
  width: 60px;
  height: 60px;
  background: var(--default-color) repeat scroll 0 0;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  -webkit-animation: pulse-border 1500ms ease-out infinite;
  animation: pulse-border 1500ms ease-out infinite;
  z-index: -1;
}

.bg-theme {
  background-color: var(--default-color);
}

.shadow.theme::after {
  background: var(--default-color) none repeat scroll 0 0;
  content: "";
  height: 100%;
  left: 0;
  opacity: 0.5;
  position: absolute;
  top: 0;
  width: 100%;
  z-index: -1;
}

.shadow.theme-hard::after {
  background: var(--default-color) none repeat scroll 0 0;
  content: "";
  height: 100%;
  left: 0;
  opacity: 0.7;
  position: absolute;
  top: 0;
  width: 100%;
  z-index: -1;
}

.shadow .btn-light::after {
  background: var(--default-color);
}

.btn-theme {
  background-color: var(--default-color);
  color: #ffffff !important;
  position: relative;
  overflow: hidden;
  z-index: 1;
}

.btn-theme.border {
  background-color: transparent;
  color: var(--default-color) !important;
  border: 2px solid var(--default-color);
}

.yellow .btn-theme.border {
  background-color: transparent;
  color: #232323 !important;
  border: 2px solid #febc35;
}

.btn-theme.border:hover {
  background-color: var(--default-color);
  color: #ffffff !important;
  border: 2px solid var(--default-color);
}

a.more-btn:hover {
  color: var(--default-color);
}

.site-heading h4 {
  color: var(--default-color);
  font-weight: 600;
  text-transform: uppercase;
  font-size: 16px;
  margin-bottom: 10px;
}

.site-heading.clean h2 span {
  color: var(--default-color);
}

.site-heading h2 span {
  color: var(--default-color);
}

.site-heading h2::before {
  background: var(--default-color) none repeat scroll 0 0;
  bottom: 0;
  content: "";
  height: 2px;
  left: 50%;
  margin-left: -28px;
  position: absolute;
  width: 40px;
}

.site-heading h2::after {
  background: var(--default-color) none repeat scroll 0 0;
  bottom: 0;
  content: "";
  height: 2px;
  left: 50%;
  margin-left: 18px;
  position: absolute;
  width: 5px;
}

.site-heading h2 span {
  color: var(--default-color);
}

.top-bar-area .shape::after {
  position: absolute;
  right: 0;
  top: -100%;
  content: "";
  height: 300%;
  width: 500%;
  background: var(--default-color);
  z-index: -1;
  transform: skewX(20deg);
  border-right: 5px solid #ffffff;
}

.top-bar-area .info > ul  li a:hover {
  color: var(--default-color);
}

.top-bar-area .info .list li i {
  color: var(--default-color);
  margin-right: 5px;
  font-size: 20px;
  position: relative;
  top: 1px;
}

.top-bar-area .text-right .button::after {
  position: absolute;
  left: 0;
  top: -35px;
  content: "";
  height: 100px;
  width: 200%;
  background: var(--default-color);
  z-index: -1;
  transform: skewX(-30deg);
  border-left: 3px solid #ffffff;
}
nav.navbar.bootsnav li.search a {
  border-radius: 50%;
  padding: 0 !important;
  height: 45px;
  width: 45px;
  line-height: 45px;
  text-align: center;
  margin-left: 15px;
  background: var(--default-color);
  color: #ffffff !important;
  font-size: 14px;
}

.navbar .attr-nav .call i {
  display: inline-block;
  font-size: 22px;
  height: 50px;
  width: 50px;
  line-height: 50px;
  text-align: center;
  background: var(--default-color);
  color: #ffffff;
  border-radius: 50%;
  position: relative;
  z-index: 1;
  margin-right: 15px;
  font-weight: 300;
}
.navbar .attr-nav .call i::after {
  position: absolute;
  left: -10%;
  top: -10%;
  height: 120%;
  width: 120%;
  background: var(--default-color);
  z-index: -1;
  content: "";
  border-radius: 50%;
  opacity: 0.5;
}

.banner-area .carousel-control.theme {
  color: var(--default-color);
}

.banner-area .carousel-indicators li {
  display: block;
  height: 20px;
  width: 20px;
  margin: 10px 5px;
  border: 6px solid var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  background: transparent;
  position: relative;
  z-index: 1;
}

.banner-area .carousel-indicators li.active {
  border: 6px solid var(--default-color);
}


.banner-area .carousel-indicators.theme li.active {
  border: 6px solid var(--default-color);
}

.banner-area .carousel-indicators li::after {
  position: absolute;
  left: 50%;
  top: 50%;
  content: "";
  height: 5px;
  width: 5px;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  background: var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}

.banner-area .carousel-indicators.theme li::after {
  background: var(--default-color);
}

.banner-area .content ul li i {
  display: inline-block;
  font-size: 40px;
  margin-right: 15px;
  color: var(--default-color);
}

.banner-area.default .content h4::after {
  position: absolute;
  left: 0;
  bottom: 0;
  content: "";
  height: 10px;
  width: 100%;
  background: var(--default-color);
  z-index: -1;
}
.banner-area.shape .box-cell::before {
  position: absolute;
  left: 47%;
  bottom: 0;
  content: "";
  height: 100%;
  width: 100px;
  background: var(--default-color);
  z-index: -1;
  transform: skew(30deg);
  opacity: 0.7;
}
.banner-area.text-default h2 strong {
  font-weight: 900;
  color: var(--default-color);
}
@media only screen and (min-width: 1200px) {
  .banner-area.border-shape .content::after {
    position: absolute;
    left: -120px;
    top: 50%;
    content: "";
    height: 500px;
    width: 400px;
    border: 60px solid var(--default-color);
    z-index: -1;
    opacity: 0.4;
    transform: translateY(-50%);
    margin-top: 50px;
  }

  .yellow .banner-area.border-shape .content::after {
    border: 60px solid #febc35;
  }
}


/* ============================================================== 
     # Video Button Play
=================================================================== */
.video-play-button {
  color: var(--default-color);
  font-size: 30px;
  left: 50%;
  padding-left: 7px;
  position: absolute;
  top: 50%;
  transform: translateX(-50%) translateY(-50%);
  -webkit-transform: translateX(-50%) translateY(-50%);
  -moz-transform: translateX(-50%) translateY(-50%);
  -ms-transform: translateX(-50%) translateY(-50%);
  -o-transform: translateX(-50%) translateY(-50%);
  z-index: 1;
}

.video-play-button i {
  display: block;
  position: relative;
  z-index: 3;
  color: var(--default-color);
}

.about-area .info-content h2 strong {
  font-size: 140px;
  line-height: 110px;
  padding-right: 20px;
  color: var(--default-color);
  font-weight: 800;
}

.about-area blockquote {
  font-size: 14px;
  border-left: 2px solid var(--default-color);
  margin-top: 30px;
  margin-bottom: 0;
  padding: 0;
  padding-left: 25px;
}
.about-area .left-info h2 strong {
  font-weight: 600;
  color: var(--default-color);
}
.about-area blockquote span strong {
  color: var(--default-color);
}

.about-area .thumb .video .video-play-button:before {
  width: 60px;
  height: 60px;
  background: var(--default-color);
}

.about-area .thumb .video .video-play-button:after {
  width: 60px;
  height: 60px;
  background: var(--default-color);
}

.about-area .establish i {
  display: inline-block;
  font-size: 60px;
  margin-right: 20px;
  color: var(--default-color);
}

.about-area .content-box .item > i {
  display: block;
  font-size: 40px;
  margin-bottom: 30px;
  color: var(--default-color);
  position: relative;
  z-index: 1;
  padding-bottom: 30px;
}

/* ============================================================== 
     # About Version Two
=================================================================== */

.about-area .thumb-left .thumb .experiecne {
  text-align: left;
  position: absolute;
  left: 0;
  bottom: 50px;
  background: var(--default-color);
  padding: 50px 30px;
  border: 5px solid #ffffff;
  max-width: 250px;
}
.about-area .info ul li::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "\f058";
  font-family: "Font Awesome 5 Pro";
  font-weight: 600;
  color: var(--default-color);
}

.about-simple-area .contact i {
  display: inline-block;
  font-size: 45px;
  color: var(--default-color);
  text-align: center;
  border-radius: 8px;
  position: relative;
  z-index: 1;
  margin-right: 20px;
}

.car-about-area .info ul li .top i {
  font-size: 40px;
  color: var(--default-color);
  margin-right: 10px;
}

.features-area .features-items .item i {
  display: inline-block;
  font-size: 50px;
  margin-bottom: 30px;
  color: var(--default-color);
  position: relative;
  z-index: 1;
}

.our-features-area .feature-item .info:last-child {
  background: var(--default-color);
}

.consulting-area .inner-items .left-info::before {
  position: absolute;
  right: 0;
  top: 0;
  content: "";
  height: 100%;
  width: 300%;
  background: var(--default-color);
  z-index: -1;
}

.services-area.with-thumb .services-items .item .thumb {
  overflow: hidden;
  position: relative;
  z-index: 1;
  border-bottom: 3px solid var(--default-color);
}
.services-area.with-thumb .services-items .item .info > i {
  position: absolute;
  left: 40px;
  top: -80px;
  height: 100px;
  width: 90px;
  text-align: center;
  color: #ffffff;
  font-size: 42px;
  z-index: -1;
  line-height: 100px;
  background: var(--default-color);
}

.services-area.with-thumb .services-items .item .info a:hover {
  color: var(--default-color);
}


.services-area.with-thumb .services-items .item:hover .info .button a {
  color: var(--default-color);
}

.services-area .services-items.services-carousel .owl-dots .owl-dot span {
  display: block;
  height: 25px;
  width: 25px;
  margin: 0 5px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  background: transparent;
  position: relative;
  z-index: 1;
  opacity: 0.5;
  border: 4px solid var(--default-color);
}

.services-area .services-items.services-carousel .owl-dots .owl-dot.active span::after {
  position: absolute;
  left: 50%;
  top: 50%;
  content: "";
  height: 5px;
  width: 5px;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  background: var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}

.services-area.icon-only .services-box .item .read-more {
  position: absolute;
  bottom: -22px;
  display: inline-block;
  height: 48px;
  width: 48px;
  background: var(--default-color);
  line-height: 48px;
  color: #ffffff;
  left: 60%;
  border-radius: 50%;
  text-align: center;
  opacity: 0;
}

.services-area.icon-only .services-box .item::before {
  position: absolute;
  left: 0;
  bottom: -1px;
  content: "";
  height: 3px;
  width: 0;
  background: var(--default-color);
  transition: all 0.35s ease-in-out;
  border-radius: 50%;
}

.services-area.icon-only .services-box .item > i {
  display: inline-block;
  font-size: 60px;
  margin-bottom: 30px;
  margin-top: 25px;
  transition: all 0.35s ease-in-out;
  color: var(--default-color);
  position: relative;
  z-index: 1;
}


.car-services-area .col-lg-4 {
  background: var(--default-color);
  padding: 50px;
  display: flex;
  align-items: center;
}


.services-details-items .services-sidebar .widget-title::after {
  position: absolute;
  left: 0;
  bottom: 0;
  content: "";
  height: 2px;
  width: 50px;
  border-bottom: 2px solid var(--default-color);
}

.services-details-items .services-sidebar .services-list li.current-item a::before {
  position: absolute;
  left: 0;
  top: 0;
  content: "";
  height: 100%;
  width: 5px;
  background: var(--default-color);
}

.services-details-items .services-sidebar .services-list li a:hover {
  color: var(--default-color);
}

.services-details-items .services-sidebar .single-widget.quick-contact .content i {
  display: inline-block;
  font-size: 40px;
  color: #ffffff;
  margin-bottom: 35px;
  height: 100px;
  width: 100px;
  line-height: 100px;
  background: var(--default-color);
  border-radius: 50%;
  position: relative;
  z-index: 1;
  text-align: center;
}

.services-details-items .services-sidebar .single-widget.quick-contact .content i::after {
  position: absolute;
  left: -10%;
  top: -10%;
  content: "";
  height: 120%;
  width: 120%;
  background: var(--default-color);
  z-index: -1;
  border-radius: 50%;
  opacity: 0.3;
}

.services-details-items .services-sidebar .single-widget.brochure a {
  display: flex;
  align-items: center;
  margin-top: 15px;
  background: var(--default-color);
  color: #ffffff;
  padding: 20px 30px;
  text-transform: uppercase;
  font-size: 13px;
}

.services-details-items .services-sidebar .single-widget.brochure a:hover,
.services-details-items .services-sidebar .single-widget.brochure li:last-child a:hover {
  background: var(--default-color);
}

.services-details-area .features i {
  display: inline-block;
  font-size: 50px;
  color: var(--default-color);
  margin-right: 25px;
}

.work-process-area .work-pro-items .item i {
  display: inline-block;
  color: var(--default-color);
  font-size: 60px;
  margin-bottom: 25px;
}

/* Animation */
.work-process-area .work-pro-items .item::before, 
.work-process-area .work-pro-items .item::after {
  content: "";
  width: 0;
  height: 2px;
  position: absolute;
  transition: all 0.2s linear;
  background: var(--default-color);
}

.work-process-area .work-pro-items .item .item-inner::before, 
.work-process-area .work-pro-items .item .item-inner::after {
  content: "";
  width: 2px;
  height: 0;
  position: absolute;
  transition: all 0.2s linear;
  background: var(--default-color);
}

.work-with-us-area .fun-fact {
  padding: 50px 20px;
  box-shadow: 0 0 10px #cccccc;
  border-bottom: 3px solid var(--default-color);
  background: #ffff;
  border-radius: 10px;
}

.why-us-area .thumb::after {
  position: absolute;
  left: 0;
  bottom: 0;
  content: "";
  height: 50%;
  width: 100%;
  background: var(--default-color) none repeat scroll 0 0;
  z-index: -1;
  clip-path: polygon(100% 1%, 4% 100%, 100% 100%);
}

.why-us-area .info .content > h5 {
  font-weight: 600;
  color: var(--default-color);
  margin-bottom: 30px;
  font-size: 18px;
  margin-top: -5px;
  text-transform: uppercase;
}

.why-us-area .info li::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "\f058";
  color: var(--default-color);
  font-family: "Font Awesome 5 Pro";
  font-size: 16px;
  font-weight: 600;
}

.why-us-area .left-info .content {
  background: var(--default-color);
  padding: 60px 30px;
}

.chooseus-area .thumb-inner::after {
  position: absolute;
  left: -25%;
  bottom: -200px;
  content: "";
  height: 400px;
  width: 400px;
  border: 60px solid var(--default-color);
  z-index: -1;
  border-radius: 50%;
}

.chooseus-area .info li::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "\f058";
  color: var(--default-color);
  font-family: "Font Awesome 5 Pro";
  font-size: 16px;
  font-weight: 600;
}

.team-area .team-carousel .owl-nav .owl-prev, 
.team-area .team-carousel .owl-nav .owl-next {
  background: transparent none repeat scroll 0 0;
  color: var(--default-color);
  font-size: 30px;
  height: 40px;
  left: -50px;
  line-height: 40px;
  margin: -20px 0 0;
  padding: 0;
  position: absolute;
  top: 50%;
  width: 40px;
}

.team-area .team-carousel.owl-carousel .owl-dots .owl-dot span {
  display: block;
  height: 25px;
  width: 25px;
  margin: 0 5px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  background: transparent;
  position: relative;
  z-index: 1;
  opacity: 0.5;
  border: 4px solid var(--default-color);
}

.team-area .team-carousel.owl-carousel .owl-dots .owl-dot.active span::after {
  position: absolute;
  left: 50%;
  top: 50%;
  content: "";
  height: 5px;
  width: 5px;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  background: var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}

.team-single-area .thumb::after {
  position: absolute;
  right: -30px;
  top: 30px;
  content: "";
  height: 100%;
  width: 100%;
  background: var(--default-color);
  z-index: -1;
  opacity: 0.2;
}

.team-single-area .team-content-top .right-info span {
  display: block;
  text-transform: uppercase;
  color: var(--default-color);
  font-weight: 600;
  margin-bottom: 25px;
}

.team-single-area .right-info ul li a:hover {
  color: var(--default-color);
}

.team-single-area .right-info .social .share-link > i {
  display: inline-block;
  height: 45px;
  background: #ffffff;
  box-shadow: 0 0 10px #cccccc;
  line-height: 45px;
  width: 45px;
  text-align: center;
  border-radius: 50%;
  cursor: pointer;
  color: var(--default-color);
  margin-right: 20px;
}
.skill-items .progress-box .progress .progress-bar {
  height: 6px;
  border-radius: 30px;
  background: var(--default-color);
  top: 12px;
  position: relative;
  overflow: inherit;
}

.skill-items .progress-box .progress .progress-bar::after {
  position: absolute;
  right: 4px;
  top: -28px;
  content: "\f106";
  font-family: "Font Awesome 5 Pro";
  font-weight: 600;
  color: var(--default-color);
  font-size: 18px;
}
.projects-area .info ul {
  background: var(--default-color);
  margin: 0;
  margin-top: 25px;
  color: #ffffff;
  padding: 30px;
  padding-top: 0;
  display: inline-block;
  border-radius: 10px;
  position: relative;
  z-index: 1;
  list-style: none;
}
.projects-area .info ul::after {
  position: absolute;
  left: 30px;
  top: -10px;
  content: "";
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid var(--default-color);
}
.projects-area .project-item .thumb a {
  display: inline-block;
  height: 50px;
  width: 50px;
  background: #ffffff;
  z-index: 1;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -90%);
  text-align: center;
  line-height: 50px;
  border-radius: 50%;
  box-shadow: 0 0 10px #cccccc;
  opacity: 0;
  color: var(--default-color);
}



.projects-area .item .info h4 {
  font-weight: 600;
  text-transform: uppercase;
  color: var(--default-color);
  display: inline-block;
  position: relative;
  z-index: 1;
  font-size: 16px;
}



.projects-area .project-item.projects-carousel .owl-nav .owl-prev, 
.projects-area .project-item.projects-carousel .owl-nav .owl-next {
  background: transparent none repeat scroll 0 0;
  color: var(--default-color);
  font-size: 30px;
  height: 40px;
  left: -70px;
  line-height: 40px;
  margin: -20px 0 0;
  padding: 0;
  position: absolute;
  top: 50%;
  width: 40px;
}


.project-details-area .content ul li::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "\f058";
  font-family: "Font Awesome 5 Pro";
  font-weight: 600;
  color: var(--default-color);
}


.gallery-area .gallery-items .pf-item .overlay:after {
  content: "";
  position: absolute;
  height: 100%;
  width: 100%;
  left: 170%;
  top: 0;
  transform: skewX(45deg);
  transition: all 0.55s ease-in-out;
  background-color: var(--default-color);
  opacity: 0.6;
}



.gallery-area .gallery-items .pf-item .overlay .content > a {
  display: inline-block;
  height: 50px;
  width: 50px;
  line-height: 50px;
  text-align: center;
  background: var(--default-color);
  color: #ffffff;
  border-radius: 50%;
  transform: translateY(30px);
  opacity: 0;
}


.portfolio-area .portfolio-items-area .mix-item-menu button.active {
  background: var(--default-color);
  color: #ffffff;
}



.portfolio-area .item .info span i {
  margin-right: 5px;
  color: var(--default-color);
  font-size: 16px;
  position: relative;
  top: 2px;
  font-weight: 500;
}



.portfolio-area .item .info a:hover {
  color: var(--default-color) !important;
}



.portfolio-area .item .info > a:hover {
  background: var(--default-color) !important;
  color: #ffffff !important;
}


.portfolio-area .item .thumb .overlay a {
  height: 50px;
  width: 50px;
  line-height: 50px;
  background: var(--default-color);
  display: inline-block;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  border-radius: 50%;
  box-shadow: 0 0 10px #cccccc;
  color: #ffffff;
  opacity: 0;
  text-align: center;
}



.portfolio-area .item .info .bottom a {
  display: inline-block;
  height: 45px;
  width: 45px;
  line-height: 45px;
  background: var(--default-color);
  text-align: center;
  color: #ffffff;
  border-radius: 6px;
  margin: 0;
  margin-right: 30px;
}



.portfolio-list a.load-more__btn {
  margin: 0 15px;
  display: inline-block;
  padding: 12px 40px;
  background: var(--default-color);
  color: #ffffff;
  border-radius: 30px;
  margin-top: 30px;
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  margin-bottom: 15px;
  margin-left: 0;
}


.portfolio-area .portfolio-carousel.owl-carousel .owl-dots .owl-dot span {
  display: block;
  height: 25px;
  width: 25px;
  margin: 0 5px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  background: transparent;
  position: relative;
  z-index: 1;
  opacity: 0.5;
  border: 4px solid var(--default-color);
}

.portfolio-area  .portfolio-carousel.owl-carousel .owl-dots .owl-dot.active span::after {
  position: absolute;
  left: 50%;
  top: 50%;
  content: "";
  height: 5px;
  width: 5px;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  background: var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}



.project-details-area .default-one-col-carousel .owl-nav .owl-prev, 
.project-details-area .default-one-col-carousel .owl-nav .owl-next {
  background: transparent none repeat scroll 0 0;
  color: var(--default-color);
  font-size: 30px;
  height: 40px;
  left: 15px;
  line-height: 40px;
  margin: -20px 0 0;
  padding: 0;
  position: absolute;
  top: 50%;
  width: 40px;
}

.clients-area.default-padding.bg-dark.text-light::after {
  position: absolute;
  left: -15%;
  top: 0;
  height: 101%;
  width: 63%;
  content: "";
  background: var(--default-color);
  z-index: -1;
  transform: skewX(-10deg);
}



.testimonials-area .testimonial-content .content .rating {
  display: block;
  margin-bottom: 30px;
  color: var(--default-color);
}


.testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-prev, 
.testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-next {
  background: transparent;
  color: var(--default-color);
  font-size: 24px;
  margin: 0;
  padding: 10px;
}



.testimonials-area .testimonial-content.testimonials-carousel .owl-dots .owl-dot span {
  display: block;
  height: 25px;
  width: 25px;
  margin: 0 5px;
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
  background: transparent;
  position: relative;
  z-index: 1;
  opacity: 0.5;
  border: 4px solid var(--default-color);
}

.testimonials-area .testimonial-content.testimonials-carousel .owl-dots .owl-dot.active span::after {
  position: absolute;
  left: 50%;
  top: 50%;
  content: "";
  height: 5px;
  width: 5px;
  transform: translate(-50%, -50%);
  -webkit-transform: translate(-50%, -50%);
  -moz-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  -o-transform: translate(-50%, -50%);
  background: var(--default-color);
  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;
}



.blog-area .thumb .date strong {
  display: block;
  font-weight: 800;
  font-size: 14px;
  text-transform: uppercase;
  background: var(--default-color);
  color: #ffffff;
  padding: 0 21px;
}

.blog-area.full-blog .item .info .meta ul li a:hover {
  color: var(--default-color);
}

.blog-area .item blockquote {
  position: relative;
  z-index: 1;
  border: none;
  font-size: 22px;
  margin-top: 30px;
  margin-bottom: 30px;
  color: #cccccc;
  line-height: 36px;
  background: #022147;
  padding: 80px 50px;
  font-style: italic;
  border-left: 5px solid var(--default-color);
}
.blog-area .item blockquote a:hover {
  color: var(--default-color);
}


.blog-area .item .info .meta ul li a:hover {
  color: var(--default-color);
}



.blog-area .item .info h2 a:hover,
.blog-area .item .info h3 a:hover,
.blog-area .item .info h4 a:hover {
  color: var(--default-color);
}



.blog-area .item .info .content h4 a:hover {
  color: var(--default-color);
}



.pagi-area .pagination li.active a {
  background: var(--default-color);
  border-color: var(--default-color);
}



.blog-area .sidebar .title h4::after {
  position: absolute;
  left: 0;
  bottom: 0;
  content: "";
  height: 2px;
  width: 50px;
  border-bottom: 2px solid var(--default-color);
}



.blog-area .sidebar button[type="submit"] {
    border: none;
    color: #ffffff;
    font-weight: 500;
    letter-spacing: 1px;
    min-height: 50px;
    width: 50px;
    position: absolute;
    right: 5px;
    text-transform: uppercase;
    top: 5px;
    -webkit-transition: all 0.35s ease-in-out;
    -moz-transition: all 0.35s ease-in-out;
    -ms-transition: all 0.35s ease-in-out;
    -o-transition: all 0.35s ease-in-out;
    transition: all 0.35s ease-in-out;
    font-size: 16px;
    background: var(--default-color);
    border-radius: 8px;
}

.blog-area .sidebar input[type="submit"]:hover {
  background: var(--default-color) none repeat scroll 0 0;
}



.blog-area .sidebar .sidebar-item li a:hover {
  color: var(--default-color);
}



.sidebar-item.recent-post li a:hover {
  color: var(--default-color);
}



.sidebar-item.tags ul li a:hover {
  color: var(--default-color);
}


.blog-area .sidebar .sidebar-item.add-banner .sidebar-info::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "";
  height: 100%;
  width: 100%;
  background: var(--default-color);
  z-index: -1;
  opacity: 0.7;
}



/* Blog Single */
.blog-area.single .item .content-box span {
  background: var(--default-color) none repeat scroll 0 0;
  color: #ffffff;
  display: inline-block;
  font-weight: 600;
  letter-spacing: 1px;
  padding: 3px 20px;
  text-transform: uppercase;
}



.blog-area .blog-content .share li a {
  display: inline-block;
  color: var(--default-color);
}


.pagination li a {
  display: inline-block;
  padding: 15px 20px;
  border-radius: 5px;
  margin: 0 2px;
  color: var(--default-color);
  font-weight: 800;
}

.pagination li.page-item.active a {
  background: var(--default-color);
  border-color: var(--default-color);
}


.contact-area .contact-items .item a:hover {
  color: var(--default-color);
}



.contact-area .contact-items .content button {
  background: var(--default-color);
  color: #ffffff;
  border: none;
  padding: 15px 40px;
  text-transform: uppercase;
  font-weight: 600;
  font-size: 14px;
  position: relative;
  z-index: 1;
  transition: all 0.35s ease-in-out;
}


.error-page-area .error-box form button {
  position: absolute;
  right: 0;
  top: 0;
  border: none;
  min-height: 50px;
  width: 50px;
  background: var(--default-color);
  color: #ffffff;
}



footer .contact ul li a:hover {
  color: var(--default-color);
}

footer .contact ul li i {
  color: var(--default-color);
}
footer .opening-hours li .closed{
  background: var(--default-color);
}



footer .link ul li a:hover {
  color: var(--default-color);
}


.navbar .side .widget .contact li .icon i {
    color: var(--default-color);
  }

 nav.navbar .quote-btn a {
    border: 2px solid var(--default-color);
  }
  
   nav.navbar.bootsnav li.dropdown ul.dropdown-menu > li > a .badge {
    background: var(--default-color);
  }
  
  .attr-nav > ul > li > a span.badge {
    background-color: var(--default-color);
  }
  
  .attr-nav > ul > li.button a {
      background: var(--default-color);
  }

.navbar.bg-dark .top-search {
    background: var(--default-color) none repeat scroll 0 0;
  }
  
  .navbar .side .widget li a:hover {
    color: var(--default-color);
  }
  
  .navbar .side .widget.social li a:hover {
    background: var(--default-color) none repeat scroll 0 0;
    color: #ffffff;
  }
  
  .navbar .side .address li .icon i {
    color: var(--default-color);
  }
  
  .side .widget ul.link li a {
    color: var(--default-color);
  }
  
  nav.navbar.bootsnav .share.dark ul > li > a {
    background-color: var(--default-color);
    color: #ffffff;
  }
  
  nav.navbar.bootsnav .share ul > li > a:hover {
    color: var(--default-color);
  }
  
   nav.navbar.bootsnav ul.nav > li > a.active {
      color: var(--default-color);
    }
    
     nav.navbar.bootsnav.active-bg ul.nav > li > a.active {
      background: var(--default-color) !important;
    }

 nav.navbar.bootsnav.active-border ul.nav > li > a.active::before {
      border-bottom: 3px solid var(--default-color);
    }
    
     nav.navbar.bootsnav ul.nav > li.active > a {
      color: var(--default-color);
    }
    
    nav.navbar.bootsnav.active-full ul.nav > li > a.active,
    nav.navbar.bootsnav.active-full ul.nav > li > a:hover {
      background: var(--default-color) none repeat scroll 0 0 !important;
      color: #ffffff;
    }
    
    nav.navbar.bootsnav ul.nav > li > a:hover {
      color: var(--default-color);
    }
    
    nav.navbar.bootsnav ul.navbar-right li.dropdown ul.dropdown-menu li a:hover {
      color: var(--default-color);
    }
    
    nav.navbar.bootsnav ul.navbar-left li.dropdown ul.dropdown-menu li a:hover {
      color: var(--default-color);
    }
    
    nav.navbar.bootsnav ul.dropdown-menu.megamenu-content .content ul.menu-col li a:hover {
      color: var(--default-color);
    }
    
    nav.bootsnav.navbar-sidebar ul.nav > li > a:hover {
      color: var(--default-color);
    }
    
     nav.navbar.bootsnav ul.nav li.dropdown > ul.dropdown-menu li:hover > a {
      background-color: transparent !important;
      color: var(--default-color) !important;
    }
    
    .attr-nav > ul > li.contact i {
    color: var(--default-color);
  }
  
  .attr-nav.menu li:last-child a {
    background: var(--default-color) none repeat scroll 0 0;
  }

.attr-nav.button li a i {
    margin-right: 3px;
    color: var(--default-color);
  }
  
  .navbar .attr-nav.contact li {
    color: var(--default-color);
  }
  
  .navbar .attr-nav.contact li p {
    color: var(--default-color);
  }
  
  .navbar.bootsnav.navbar-fixed .attr-nav li.btn a {
    color: var(--default-color);
  }
  
  .navbar.bootsnav .attr-nav li.btn a {
    border: 2px solid var(--default-color);
  }
  
  @media (min-width: 1024px) {
  
  
    nav.navbar.bootsnav.bg-theme {
      background: var(--default-color);
    }
}
  
  nav.navbar.navbar-default.bootsnav.navbar-fixed-light::after {
      background: var(--default-color);
    }
    
nav.navbar.navbar-default.bootsnav.navbar-fixed-light a.navbar-brand::before {
      background: var(--default-color);
    }
    

/* Color CSS for Unit test */
.blog-area .single-item.sticky .item::after {
  background: var(--default-color);
}

.blog-area.full-blog .item .info .meta ul li i {
  color: var(--default-color);
}

.blog-area.full-blog .item .info .meta ul li a:hover {
  color: var(--default-color);
}
    
.pagi-area .pagination li span.pagination.current, 
.pagi-area .pagination li a:hover {
  background: var(--default-color);
  border-color: var(--default-color);;
}

.post-nav-links .current, 
.post-nav-links a:hover {
  background: var(--default-color);
  border-color: var(--default-color);
}

.page-links .current, .page-links a:hover {
  background: var(--default-color);
  border-color: var(--default-color);
}

.widget_block.widget_search form .wp-block-search__inside-wrapper button {
  background: var(--default-color) !important;
}

.wp-block-group__inner-container h2::after {
  border-bottom: 2px solid var(--default-color);
}

.wp-block-calendar tbody td#today {
  background: var(--default-color);
  border-color: var(--default-color);
}

.wp-block-calendar nav.wp-calendar-nav a:hover {
  color: var(--default-color);
}

.has-avatars.wp-block-latest-comments li footer time.wp-block-latest-comments__comment-date {
  color: var(--default-color);
}

.post-password-form input[type="submit"] {
  background: var(--default-color) !important;
}

.wp-block-search .wp-block-search__button {
  background: var(--default-color);
}

.blog-area .sidebar .title h4::after {
  border-bottom: 2px solid var(--default-color);
}

.widget_tag_cloud a:hover {
  background: var(--default-color);
  background-color: var(--default-color);
}

.bg-dark .widget_tag_cloud a:hover {
  background: var(--default-color);
  background-color: var(--default-color);
}

.widget_search button[type="submit"] {
  color: var(--default-color) !important;
  background: var(--default-color);
}

.sidebar-item.widget_rss .rss-date {
  color: var(--default-color);
}

.sidebar-item.widget_rss cite {
  color: var(--default-color);
}

.widget_recent_comments li span.comment-author-link a {
  color: var(--default-color) !important;
}

.wp-calendar-table tr td a {
  color: var(--default-color);
}

.wp-calendar-table tbody td#today {
  background: var(--default-color);
}

.widget_calendar table td a {
  color: var(--default-color) !important;
}

table td a {
  color: var(--default-color);
}

.widget_calendar .calendar_wrap nav.wp-calendar-nav a:hover {
  color: var(--default-color);
}

.blog-area a:hover,
.page-content a:hover {
  color: var(--default-color);
}

blockquote {
  border-left: 5px solid var(--default-color);
}

.blog-area .info .footer-entry a:hover {
  background: var(--default-color);
}

.post-pagi-area a {
  color: var(--default-color);
}

.post-pagi-area a:hover {
  background: var(--default-color);
}

.post-pagi-area a:hover {
  color: var(--default-color);
}

.comments-list .comment-item .content .reply a:hover {
  background: var(--default-color);
}

.comment-item .comments-info a:hover {
  background: var(--default-color);
}

.comments-form button {
  background-color: var(--default-color);
  border: 2px solid var(--default-color);
}


.comments-area .comment-respond .comment-reply-title small a {
  color: var(--default-color);
}

.comments-area .comment-respond form button {
  background-color: var(--default-color);
  border: 2px solid var(--default-color);
}

footer .f-item ul li a:hover {
  color: var(--default-color);
}

/* ============================================================== 
     # Preloader 
=================================================================== */
.no-js #loader {
  display: none;
}

.js #loader {
  display: block;
  position: absolute;
  left: 100px;
  top: 0;
}

.se-pre-con {
  position: fixed;
  left: 0px;
  top: 0px;
  width: 100%;
  height: 100%;
  z-index: 999999;
  background: url(assets/img/preloader.gif) center no-repeat #fff;
  text-align: center;
}

.top-bar-area.bg-dark {
  background: var(--topbar-color) !important;
}
footer.bg-dark {
  background: var(--footer-color) !important;
}
.bg-dark {
  background: var(--sec-color) none repeat scroll 0 0 !important;
}

.it-solution .blog-area .thumb .date strong {
  background: var(--default-color);
}

.it-solution .site-heading h4 {
  color: var(--default-color);
}
.it-solution .site-heading h2::before,
.it-solution .site-heading h2::after {
  background: var(--default-color);
}

.it-solution .work-process-area .work-pro-items .item .item-inner::before, 
.it-solution .work-process-area .work-pro-items .item .item-inner::after {
  background: var(--default-color);
}

.it-solution .work-process-area .work-pro-items .item::before, 
.it-solution .work-process-area .work-pro-items .item::after {
  background: var(--default-color);
}

.it-solution .work-process-area .work-pro-items .item i {
  color: var(--default-color);
  font-weight: 300;
  font-size: 50px;
}

.it-solution .bg-theme {
  background: var(--default-color);
}

.it-solution .chooseus-area .info li::after {
  position: absolute;
  left: 0;
  top: 0;
  content: "\f00c";
  font-family: "Font Awesome 5 Pro";
  font-weight: 100;
  height: 35px;
  width: 35px;
  line-height: 35px;
  background: var(--sec-color);
  text-align: center;
  border-radius: 50%;
  color: #ffffff;
}

.appoinment-form button {
  width: 100%;
  background: var(--default-color);
  padding: 0 15px;
  border-radius: 5px;
  font-weight: 600;
  min-height: 50px;
  border: none !important;
  color: #ffffff;
}

.about-style-four ul li::after {
  position: absolute;
  left: 0;
  top: 50%;
  content: "\f00c";
  font-family: "Font Awesome 5 Pro";
  font-size: 14px;
  height: 30px;
  width: 30px;
  line-height: 30px;
  background: var(--sec-color);
  text-align: center;
  color: #ffffff;
  font-weight: 300;
  border-radius: 50%;
  transform: translateY(-50%);
}

.it-solution .consulting-area .inner-items .left-info::before {
  background: var(--sec-color);
}

.about-style-four .btn-dark.theme{
  background: var(--default-color);
}
.about-style-four h4 {
  text-transform: uppercase;
  font-weight: 600;
  color: var(--default-color);
}

.it-solution .btn-theme {
  background-color: var(--default-color);
}

.it-solution .chooseus-area .thumb-inner::after {
  border-color: var(--default-color);
}

/* ============================================================== 
     # Topbar
=================================================================== */

.business nav.navbar.bootsnav li.search a,
.business .topbar-style-three .logo a::after,
.it-solution .top-bar-area.bg-dark{
  background-color: var(--topbar-color) !important;
}

.business .topbar-style-three .info ul li i{
  color: var(--topbar-color) !important;
}

.business .topbar-style-three {
  border-bottom: 5px solid var(--topbar-color) ;
}


/* ============================================================== 
     # Solar Energy 
=================================================================== */
.about-style-five h4,
.choose-us-style-five .contact i,
.choose-us-style-five .fun-fact .timer,
.choose-us-style-five .fun-fact .operator,
.choose-us-style-five h4,
.energy .projects-area .item .info h4,
.energy .projects-area .project-item.projects-carousel .owl-nav .owl-prev, 
.energy .projects-area .project-item.projects-carousel .owl-nav .owl-next,
.energy .testimonials-area .testimonial-content .content .rating,
.energy .testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-prev, 
.energy .testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-next,
.energy .site-heading h4 {
  color: var(--default-color);
}

.energy .projects-area .info ul::after {
  border-bottom-color: var(--default-color);
}

.about-style-five blockquote {
  border-left: 2px solid var(--default-color);
}

.energy .projects-area .info ul,
.energy .clients-area.default-padding.bg-dark.text-light::after,
.energy .site-heading h2::before,
.energy .site-heading h2::after,
.energy .blog-area .thumb .date strong {
  background: var(--default-color);
}

/* ============================================================== 
     # Buisness
=================================================================== */

.energy footer .opening-hours li .closed,
.yellow footer .opening-hours li .closed,
.energy .btn-theme,
.navbar.navbar-default .container-fluid .attr-nav > ul > li.button a,
.yellow .work-process-area .work-pro-items .item .item-inner::before, .yellow .work-process-area .work-pro-items .item .item-inner::after,
.yellow .work-process-area .work-pro-items .item::before, .yellow .work-process-area .work-pro-items .item::after,
.business .banner-area .carousel-indicators li::after,
.business .btn-theme,
.it-solution .attr-nav > ul > li.button a,
.yellow .our-features-area .feature-item .info:last-child,
.yellow .navbar .attr-nav .call i,
.yellow .navbar .attr-nav .call i::after,
.yellow .top-bar-area .shape::after,
.banner-area.banner-box .box-cell::before,
.nav-tabs .nav-item a.active::after,
.yellow .clients-area.default-padding.bg-dark.text-light::after,
.yellow .blog-area .thumb .date strong,
.portfolio-area .item .info .right a,
.yellow .services-area .services-items.services-carousel .owl-dots .owl-dot.active span::after,
.yellow .projects-area .info ul,
.yellow .why-us-area .left-info .content,
.yellow .services-area.with-thumb .services-items .item .info > i,
.yellow .video-btn i,
.yellow .btn-theme,
.business .why-us-area .left-info .content,
.business .work-process-area .work-pro-items .item .item-inner::before, 
.business .work-process-area .work-pro-items .item .item-inner::after,
.business .work-process-area .work-pro-items .item::before, 
.business .work-process-area .work-pro-items .item::after,
.business .gallery-area .gallery-items .pf-item .overlay:after,
.business .gallery-area .gallery-items .pf-item .overlay .content > a,
.business .site-heading h2::after,
.business .site-heading h2::before,
.business .blog-area .thumb .date strong {
  background: var(--default-color);
}


.energy footer .contact ul li i,
.yellow footer .contact ul li i,
.energy .banner-area .carousel-control.theme,
.yellow .work-process-area .work-pro-items .item i,
.yellow .banner-area .carousel-control.theme,
.yellow .top-bar-area .info .list li i,
.side .widget.newsletter form span.input-group-addon button,
.service-item-style-three h6,
.service-item-style-three i,
.about-style-four-info h4,
.tab-content .tab-pane ul li::after,
.portfolio-area .item .info span strong,
.yellow .about-area .info ul li::after,
.yellow .why-us-area .info li::after,
.yellow .projects-area .project-item.projects-carousel .owl-nav .owl-prev, 
.yellow .projects-area .project-item.projects-carousel .owl-nav .owl-next,
.yellow .testimonials-area .testimonial-content .content .rating,
.business .about-style-three h4,
.business .about-style-three .award i,
.business .services-style-four .item i,
.business .why-us-area .info li::after,
.business .work-process-area .work-pro-items .item i,
.business .testimonials-area .testimonial-content .content .rating,
.business .testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-prev, 
.business .testimonials-area .testimonial-content.testimonials-carousel .owl-nav .owl-next,
.business .site-heading h4 {
  color: var(--default-color);
}

.yellow .site-heading h2::after,
.yellow .site-heading h2::before {
  background: var(--default-color) none repeat scroll 0 0;
}

.yellow .video-btn i::after {
  background: var(--default-color) repeat scroll 0 0;
}

.yellow .projects-area .info ul::after {
  border-bottom: 10px solid var(--default-color);
}

.yellow .services-area .services-items.services-carousel .owl-dots .owl-dot span {
  border: 4px solid var(--default-color);
}

.business .banner-area .carousel-indicators li,
.business .banner-area .carousel-indicators li.active {
  border-color: var(--default-color);
}



</style>

<?php 
}
}
add_action('wp_head', 'dustra_customize_css');

}

?>