<?php
/**
 * The template for displaying the footer
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Dustra
 */
?>

<!-- Start Footer 
============================================= -->
<footer class="bg-dark text-light">
    <div class="container">
        <?php if(is_active_sidebar('footer-sidebar1') || is_active_sidebar('footer-sidebar2')|| is_active_sidebar('footer-sidebar3') || is_active_sidebar('footer-sidebar4') ):?>
        <div class="f-items default-padding">
            <div class="row">

                <?php if(is_active_sidebar('footer-sidebar1')):?>
                    <div class="col-lg-4 col-md-6 single-item">
                        <?php dynamic_sidebar('footer-sidebar1');?>
                    </div>    
                <?php endif;?>
                <?php if(is_active_sidebar('footer-sidebar2')):?>
                    <div class="col-lg-2 col-md-6 single-item">
                        <?php dynamic_sidebar('footer-sidebar2')?>
                    </div>
                <?php endif;?>
                <?php if(is_active_sidebar('footer-sidebar3')):?>
                    <div class="col-lg-2 col-md-6 single-item">
                        <?php dynamic_sidebar('footer-sidebar3')?>
                    </div>
                <?php endif;?>
                <?php if(is_active_sidebar('footer-sidebar4')):?>
                    <div class="col-lg-4 col-md-6 single-item">
                        <?php dynamic_sidebar('footer-sidebar4')?>
                    </div>
                <?php endif;?>
                
            </div>
        </div>
        <?php endif;?>
    </div>
    <!-- Fixed Shape -->
    <?php if(is_active_sidebar('footer-sidebar1') || is_active_sidebar('footer-sidebar2')|| is_active_sidebar('footer-sidebar3') || is_active_sidebar('footer-sidebar4') ):?>
    <div class="footer-bottom">
    <?php else:?>
    <div class="footer-bottom before-activate-plugin">
    <?php endif;?>    
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <?php global $dustra_option; if(!empty($dustra_option['footer_copyright'])):?>
                        <p><?php global $dustra_option; echo esc_html($dustra_option['footer_copyright']); ?></p>
                    <?php else:?>
                        <p><?php echo esc_html__("© Copyright 2021. All Rights Reserved by validthemes",'dustra'); ?></p>
                    <?php endif;?>    
                   
                </div>
                <?php if ( has_nav_menu( 'footer-menu' ) ) : ?>
                    <div class="col-lg-6 text-right">
                        <?php
                        wp_nav_menu( array(
                            'theme_location' => 'footer-menu',
                            'container'       => 'ul',
                        ) );
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <?php if(is_active_sidebar('footer-sidebar1') || is_active_sidebar('footer-sidebar2')|| is_active_sidebar('footer-sidebar3') || is_active_sidebar('footer-sidebar4') ):?>
    <!-- Start Footer Bottom -->

    <div class="fixed-shape">
        
        <?php global $dustra_option; if(!empty($dustra_option['fotter_bg']['url']) && isset($dustra_option['fotter_bg']['url'])):?>
            <img src="<?php echo esc_url($dustra_option['fotter_bg']['url']);?>" alt="<?php echo esc_attr__("dustra",'dustra');?>">
        <?php else :?>
            <img src="<?php echo get_template_directory_uri() ?>/assets/img/shape/footer-shape.png" alt="<?php echo esc_attr__("dustra",'dustra');?>">
        <?php endif;?>
    </div>
    <!-- End Fixed Shape -->
    <?php endif;?>
    
</footer>
<!-- End Footer -->
<?php wp_footer(); ?>
</body>
</html>