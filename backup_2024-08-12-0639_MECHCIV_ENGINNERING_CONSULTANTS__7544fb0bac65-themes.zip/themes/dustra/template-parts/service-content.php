<?php
/**
 * Template part for displaying single service posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dustra
 */
$service_extra_title = get_post_meta( get_the_ID(), '_extra_title', true );
?>
<div class="col-lg-8 services-single-content">
    <?php
        if (has_post_thumbnail( )) :
            the_post_thumbnail('dustra_770x361'); 
        endif; 
    ?>
    <?php if(!empty($service_extra_title)): ?>
    	<h2><?php echo esc_html($service_extra_title);?></h2>
    <?php endif;?>
    <?php the_content();?>
</div>   