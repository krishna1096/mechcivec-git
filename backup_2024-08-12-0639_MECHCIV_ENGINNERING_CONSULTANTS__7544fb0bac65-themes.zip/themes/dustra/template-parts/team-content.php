<?php
/**
 * Template part for displaying single team posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dustra
 */

$designation = get_post_meta( get_the_ID(), '_designation', true );
$email = get_post_meta( get_the_ID(), '_email', true );
$phone = get_post_meta( get_the_ID(), '_phone', true );
$contact_link = get_post_meta( get_the_ID(), '_contact', true );
$facebook = get_post_meta( get_the_ID(), '_facebook', true );
$twitter = get_post_meta( get_the_ID(), '_twitter', true );
$youtube = get_post_meta( get_the_ID(), '_youtube', true );
$left_content = wpautop( get_post_meta( get_the_ID(), 'team_content', true ) );
$entries    = get_post_meta( get_the_ID(), '_team-meta', true );
?>
<div class="team-content-top">
	<div class="row align-center">
	    <div class="col-lg-5 left-info">
	        <div class="thumb">
	            <?php the_post_thumbnail('dustra_700x800');?>
	        </div>
	    </div>
	    <div class="col-lg-7 right-info">
	        <h2><?php the_title();?></h2>
	        <span><?php echo esc_html($designation);?></span>
	        <p>
	            <?php  echo get_the_content();?>
	        </p>
	        <ul>
	        	<?php if(!empty($email)):?>
	            <li>
	                <strong><?php echo esc_html__('Email:','dustra'); ?></strong>
	                <a href="mailto:<?php echo esc_html($email);?><"><?php echo esc_html($email);?></a>
	            </li>
	             <?php endif;?>
	            <?php if(!empty($phone)):?>
	            <li>
	                <strong><?php echo esc_html__('Phone:','dustra'); ?></strong>
	                <a href="tel:<?php echo esc_html($phone);?>"><?php echo esc_html($phone);?></a>
	            </li>
	            <?php endif;?>
	        </ul>
	        <div class="social">
	            <a class="btn btn-theme effect btn-sm" href="<?php echo esc_url($contact_link); ?>"><?php echo esc_html__('Contact Me','dustra'); ?></a>
	            <div class="share-link">
	                <i class="fas fa-share-alt"></i>
	                <ul>
	                	<?php if(!empty($facebook)):?>
	                    <li class="facebook">
	                        <a href="<?php echo esc_url($facebook);?>">
	                            <i class="fab fa-facebook-f"></i>
	                        </a>
	                    </li>
	                    <?php endif;?>
	                    <?php if(!empty($twitter)):?>
	                    <li class="twitter">
	                        <a href="<?php echo esc_url($twitter);?>">
	                            <i class="fab fa-twitter"></i>
	                        </a>
	                    </li>
	                    <?php endif;?>
	                    <?php if(!empty($youtube)):?>
	                    <li class="youtube">
	                        <a href="<?php echo esc_url($youtube);?>">
	                            <i class="fab fa-youtube"></i>
	                        </a>
	                    </li>
	                    <?php endif;?>
	                </ul>
	            </div>
	        </div>
	    </div>
	</div>
	 <div class="bottom-info">
	    <div class="row">
	        <div class="col-lg-6">
	            <?php echo wp_specialchars_decode(esc_html($left_content,'dustra')); ?>
	        </div>
	        <div class="col-lg-6">
	            <div class="skill-items">
	                <!-- Progress Bar Start -->
	                <?php 
		                if (is_array($entries) || is_object($entries)) :
		                    foreach( $entries as $entry ) :
		                    $title  =!empty($entry['_accordion-title']) ?  $entry['_accordion-title'] : '';
		                    $number   =!empty($entry['_accordian-number']) ?  $entry['_accordian-number'] : '';
		            ?>
	                <div class="progress-box">
	                    <h5><?php echo esc_html($title,'dustra');  ?></h5>
	                    <div class="progress">
	                        <div class="progress-bar" role="progressbar" data-width="<?php echo esc_html($number,'dustra');  ?>">
	                             <span><?php echo esc_html($number);  ?></span>
	                        </div>
	                    </div>
	                </div>
			        <?php     
		                endforeach;
		                endif;    
		            ?>
	               
	                <!-- End Progressbar -->
	            </div>
	        </div>
	    </div>
	</div>
</div>