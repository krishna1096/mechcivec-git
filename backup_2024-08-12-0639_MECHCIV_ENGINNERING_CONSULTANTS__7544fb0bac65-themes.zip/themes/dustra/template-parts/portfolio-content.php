<?php
/**
 * Template part for displaying single portfolio posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Dustra
 */

    $entries    = get_post_meta( get_the_ID(), '_accordion-meta', true );
    $extra_content = wpautop( get_post_meta( get_the_ID(), 'portfolio_content', true ) );
?>
<div class="col-lg-12 content">
    <?php if (has_post_thumbnail( )) :?>
        <?php the_post_thumbnail('dustra_1230x574'); ?>
    <?php endif; ?>
    <div class="row">
        <div class="col-lg-4 order-lg-last">
            <div class="project-info">
            <?php 
                if (is_array($entries) || is_object($entries)) :
                    foreach( $entries as $entry ) :
                    $title  =!empty($entry['_accordion-title']) ?  $entry['_accordion-title'] : '';
                    $desc   =!empty($entry['_accordion-desc']) ?  $entry['_accordion-desc'] : '';
            ?>
                <div class="item">
                    <h5><?php echo esc_html($title,'dustra');  ?></h5>
                    <span><?php echo esc_html($desc,'dustra');  ?></span>
                </div>
            <?php     
                endforeach;
                endif;    
            ?>
                
            </div>
        </div>
        <div class="col-lg-8">
            <?php
                the_content();
            ?>
        </div>
    </div>
    <?php echo html_entity_decode(esc_html($extra_content,'dustra')); ?>
</div>