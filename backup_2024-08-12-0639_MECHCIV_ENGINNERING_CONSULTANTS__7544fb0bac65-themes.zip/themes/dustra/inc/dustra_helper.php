<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function dustra_sidebar_areas() {


    register_sidebar( array(
        'name'          => esc_html__( 'Blog Sidebar','dustra'),
        'id'            => 'blog-sidebar',
        'description'   => esc_html__( 'Blog Sidebar','dustra'),
        'before_widget' => '<div id="%1$s" class="sidebar-item %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<div id="%1$s" class="title"><h4>',
        'after_title'   => '</div></h4>',
    ) );
    if( class_exists( 'ReduxFramework' ) ):
        register_sidebar( array(
            'name'          => esc_html__( 'Service Sidebar','dustra'),
            'id'            => 'service-sidebar',
            'description'   => esc_html__( 'Service Sidebar','dustra'),
            'before_widget' => '<div id="%1$s" class="sidebar-item %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<div id="%1$s" class="title"><h4>',
            'after_title'   => '</div></h4>',
        ) );
        
        register_sidebar( array(
            'name'          => __( 'Footer Sidebar 1', 'dustra' ),
            'id'            => 'footer-sidebar1',
            'description'   => esc_html__('Widgets will be shown in footer area', 'dustra'),
            'class'         => '',
            'before_widget' => '<div class="f-item %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )); 
        register_sidebar( array(
            'name'          => __( 'Footer Sidebar 2', 'dustra' ),
            'id'            => 'footer-sidebar2',
            'description'   => esc_html__('Widgets will be shown in footer area', 'dustra'),
            'class'         => '',
            'before_widget' => '<div class="f-item %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )); 
        register_sidebar( array(
            'name'          => __( 'Footer Sidebar 3', 'dustra' ),
            'id'            => 'footer-sidebar3',
            'description'   => esc_html__('Widgets will be shown in footer area', 'dustra'),
            'class'         => '',
            'before_widget' => '<div class="f-item %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        )); 
        register_sidebar( array(
            'name'          => __( 'Footer Sidebar 4', 'dustra' ),
            'id'            => 'footer-sidebar4',
            'description'   => esc_html__('Widgets will be shown in footer area', 'dustra'),
            'class'         => '',
            'before_widget' => '<div class="f-item %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="widget-title">',
            'after_title'   => '</h4>'
        ));  
    endif;
}
    add_action( 'widgets_init', 'dustra_sidebar_areas' );

    function dustra_pagination() {
        global $wp_query;
        $links = paginate_links( array(
            'current' => max( 1, get_query_var( 'paged' ) ),
            'total'   => $wp_query->max_num_pages,
            'type'    => 'list',
            'prev_text'          => '<i class="fas fa-angle-double-left"></i>',
            'next_text'          => '<i class="fas fa-angle-double-right"></i>',

        ) );

        $links = str_replace( "page-numbers", "pagination", $links );

        echo wp_kses_post( $links );
    }
  
    /**
    * Wrapper function to deal with backwards compatibility.
    */
    if ( ! function_exists( 'wp_body_open' ) ) {
        function wp_body_open() {
            do_action( 'wp_body_open' );
        }
    }

    /** Preloader **/
    if ( ! function_exists( 'dustra_preloader' ) ) :
        function dustra_preloader() {
            global $dustra_option;
            if( isset( $dustra_option['preload_position'] ) && $dustra_option['preload_position']== '1'):
            ?>
            <div class="se-pre-con" style="background-image: url(<?php echo esc_url($dustra_option['preloader']['url']); ?>);"></div>
            <?php else: ?>
                
            <?php endif;?>    
        <?php }
    endif;

    function dustra_body_classes( $classes ) {
        
        if( class_exists( 'ReduxFramework' ) ){
            global $dustra_option;
            $blog_color_style = $dustra_option['color_style'];
            $page_color = get_post_meta( get_the_id(), 'page_color', true);

            if ((get_post_type() === 'post' && $blog_color_style == '1')) {
                $classes[] = 'yellow';
            }elseif($page_color == '2'){
                $classes[] = 'yellow';
            }
            
            if ((get_post_type() === 'post' && $blog_color_style == '3')) {
                $classes[] = 'business';
            }elseif($page_color == '3'){
                $classes[] = 'business';
            }

            if ((get_post_type() === 'post' && $blog_color_style == '4')) {
                $classes[] = 'it-solution';
            }elseif($page_color == '4'){
                $classes[] = 'it-solution';
            }

            if ((get_post_type() === 'post' && $blog_color_style == '5')) {
                $classes[] = 'energy';
            }elseif($page_color == '5'){
                $classes[] = 'energy';
            }
            
            return $classes;

        }else{
            $page_color = get_post_meta( get_the_id(), 'page_color', true); 
            if ( $page_color == '2') {
                $classes[] = 'yellow';
            }
        }
        
            return $classes;
        }
    add_filter( 'body_class','dustra_body_classes' );  
  
?>