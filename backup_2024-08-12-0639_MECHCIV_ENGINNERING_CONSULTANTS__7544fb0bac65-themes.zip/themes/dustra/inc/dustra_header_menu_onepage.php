<?php
/*
Dustra own hook
 */
if(!function_exists('dustra_header_onepage')){
    function dustra_main_menu_onepage(){
        global $dustra_option; 
        $header_menu=get_post_meta( get_the_id(), 'header_style', true);
        if( class_exists( 'ReduxFramework' )){
            $blog_header_style_one = (get_post_type() === 'post' && $dustra_option['header_style'] == '1');
            $blog_header_style_two = (get_post_type() === 'post' && $dustra_option['header_style'] == '2');
            $blog_header_style_three = (get_post_type() === 'post' && $dustra_option['header_style'] == '3');
            $blog_header_style_four = (get_post_type() === 'post' && $dustra_option['header_style'] == '4');
            $blog_header_style_five = (get_post_type() === 'post' && $dustra_option['header_style'] == '5');
            $blog_header_style_six = (get_post_type() === 'post' && $dustra_option['header_style'] == '6');
            $blog_header_style_seven = (get_post_type() === 'post' && $dustra_option['header_style'] == '7');
            $blog_header_style_eight = (get_post_type() === 'post' && $dustra_option['header_style'] == '8');
            $blog_header_style_nine = (get_post_type() === 'post' && $dustra_option['header_style'] == '9');
        }else{
            $blog_header_style_one = '0';
            $blog_header_style_two = '0';
            $blog_header_style_three ='0';
            $blog_header_style_four ='0';
            $blog_header_style_five ='0';
            $blog_header_style_six ='0';
            $blog_header_style_seven ='0';
            $blog_header_style_eight ='0';
            $blog_header_style_nine =-'0';
        }
        if ($header_menu == '1' || $blog_header_style_one) { ?>
        <!-- Start Header Style One -->
        <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-sticky bootsnav">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">
                <?php
                    if( !empty($dustra_option['header_search_button']) || $dustra_option['header_search_button'] == 1 ) :
                ?>
                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="search"><a href="<?php echo esc_url('#'); ?>"><i class="fa fa-search"></i></a></li>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->
                <?php endif; ?>
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                         <?php 

                            $page_color = get_post_meta( get_the_id(), 'page_color', true);
                            if($page_color == '2'){
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?>
                            <?php }else{ 
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_light'] ) || !empty($dustra_option['upload_logo_light'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?> 
                        <?php } ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header Style One -->

    <?php }elseif ( $header_menu == '2' || $blog_header_style_two){?>
    <!-- Start Header Style Two -->    
    <header id="home">
        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-sticky bootsnav">

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <div class="call">
                        <a href="tel:<?php global $dustra_option; $phone = $dustra_option['header_contact_number']; echo esc_attr(str_replace(' ','',"$phone")); ?>">
                        <i class="fas fa-phone"></i>
                        <div class="contact">
                            <?php global $dustra_option; if(isset($dustra_option['header_contact_number'])): ?>
                               <h4><?php echo esc_html($dustra_option['header_contact_number'],'dustra')?></h4>
                            <?php endif; ?>
                            <?php global $dustra_option; if(isset($dustra_option['header_contact_text'])): ?>
                               <span><?php echo esc_html($dustra_option['header_contact_text'],'dustra')?></span>
                            <?php endif; ?>
                        </div>
                        </a>
                    </div>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php 

                            $page_color = get_post_meta( get_the_id(), 'page_color', true);
                            if($page_color == '2'){
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?>
                            <?php }else{ 
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_light'] ) || !empty($dustra_option['upload_logo_light'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?> 
                        <?php } ?>

                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <?php
        if( class_exists( 'ReduxFramework' )){
            $blog_header_style_three = (get_post_type() === 'post' && $dustra_option['header_style'] == '3');
        }else{
            $blog_header_style_three = null;
        }
    ?>
    <!-- End Header Style Two -->
    <?php }elseif( $header_menu == '3' || $blog_header_style_three ){?>

    <!-- Start Header Style Three -->
    <header>
        <div class="container">
            <div class="row">
                <!-- Start Navigation -->
                <nav id="mainNav" class="navbar navbar-default navbar-fixed white bootsnav on no-full nav-box no-background">

                    <!-- Start Top Search -->
                    <div class="top-search">
                        <div class="container">
                            <form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
                                    <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                                    <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- End Top Search -->

                    <div class="container">  
                        <?php
                            if( !empty($dustra_option['header_search_button']) || $dustra_option['header_search_button'] == 1 ) :
                        ?>
                        <!-- Start Atribute Navigation -->
                        <div class="attr-nav">
                            <ul>
                                <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
                            </ul>
                        </div>        
                        <!-- End Atribute Navigation -->          
                        <?php endif; ?>
                        <!-- Start Header Navigation -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                                <i class="fa fa-bars"></i>
                            </button>
                            <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                            <?php 
                            $page_color = get_post_meta( get_the_id(), 'page_color', true);
                            if($page_color == '2'){
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?>
                            <?php }else{ 
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_light'] ) || !empty($dustra_option['upload_logo_light'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?> 
                            <?php } ?>
                            </a>

                        </div>
                        <!-- End Header Navigation -->

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="navbar-menu">
                            <?php
                                wp_nav_menu(array(
                                    'theme_location'  => 'onepage',
                                    'container'       => 'ul',
                                    'menu_class'      => 'nav navbar-nav navbar-right',
                                    'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                                    'walker'          => new WP_Bootstrap_Navwalker(),
                                    'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                                ));
                            ?>
                        </div><!-- /.navbar-collapse -->
                    </div>   
                    
                </nav>
                <!-- End Navigation -->
                
            </div>
        </div>
    </header>
    <!-- End Header Style Three -->
    <?php
        if( class_exists( 'ReduxFramework' )){
            $blog_header_style_four = (get_post_type() === 'post' && $dustra_option['header_style'] == '4');
        }else{
            $blog_header_style_four = null;
        }
    ?>
    <?php }elseif( $header_menu == '4' || $blog_header_style_four){?>

    <!-- Start Header Style Four -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default inc-top-bar navbar-fixed navbar-transparent white bootsnav">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' )); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <div class="call">
                        <a href="tel:+1234567890">
                            <i class="fas fa-phone"></i>
                            <div class="contact">
                                <?php global $dustra_option; if(isset($dustra_option['header_contact_number'])): ?>
                                <h4><?php echo esc_html($dustra_option['header_contact_number'],'dustra')?></h4>
                                <?php endif; ?>
                                <?php global $dustra_option; if(isset($dustra_option['header_contact_text'])): ?>
                                   <span><?php echo esc_html($dustra_option['header_contact_text'],'dustra')?></span>
                                <?php endif; ?>
                            </div>
                        </a>
                    </div>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        
                        
                        <?php 
                        global $dustra_option;
                        if(!empty($dustra_option['upload_logo_dark'] )): ?>
                            <img src="<?php echo esc_url($dustra_option['upload_logo_dark']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php else: ?>
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-light.svg' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <?php endif; ?>
                        <?php 
                        $page_color = get_post_meta( get_the_id(), 'page_color', true);
                        if($page_color == '2'){
                            global $dustra_option;
                            if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                            <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo logo-scrolled" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php else: ?>
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo logo-scrolled" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php endif; ?>
                        <?php }else{ 
                            global $dustra_option;
                            if(!empty($dustra_option['upload_logo_light'] ) || !empty($dustra_option['upload_logo_light'] )): ?>
                            <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo logo-scrolled" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php else: ?>
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo logo-scrolled" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php endif; ?> 
                        <?php } ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header Style Four -->
    <?php }elseif( $header_menu == '5' || $blog_header_style_five){?>
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default attr-border navbar-sticky bootsnav">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' )); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <?php
                            if( !empty($dustra_option['header_search_button']) || $dustra_option['header_search_button'] == 1 ) :
                        ?>
                        <li class="search"><a href="#"><i class="fa fa-search"></i></a></li>
                        <?php endif; ?>
                        <?php global $dustra_option; if(isset($dustra_option['header_contact_text'])): ?>
                        <li class="button"><a href="#"><?php echo esc_html($dustra_option['header_contact_text'],'dustra')?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                       <?php 

                            $page_color = get_post_meta( get_the_id(), 'page_color', true);
                            if($page_color == '2'){
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?>
                            <?php }else{ 
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_light'] ) || !empty($dustra_option['upload_logo_light'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?> 
                        <?php } ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                   <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <?php }elseif( $header_menu == '6' || $blog_header_style_six ){ ?>
    <!-- Header 
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default attr-bg navbar-fixed white no-background bootsnav nav-full">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container-full">
                    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' )); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">
               
                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <?php
                            if( !empty($dustra_option['header_search_button']) || $dustra_option['header_search_button'] == 1 ) :
                        ?>
                        <li class="search"><a href="#"><i class="ti-search"></i></a></li>
                        <?php endif;?>
                        <?php
                            if( !isset($dustra_option['sidemenu_position']) || $dustra_option['sidemenu_position'] == 1 ) :
                        ?>
                        <li class="side-menu">
                            <a href="#">
                                <span class="bar-1"></span>
                                <span class="bar-2"></span>
                                <span class="bar-3"></span>
                            </a>
                        </li>
                        <?php endif;?>
                    </ul>
                </div>       
                <!-- End Atribute Navigation -->
                

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <?php
                        global $dustra_option;
                        if(!empty($dustra_option['upload_logo_squre']['url'] )):
                    ?>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <img src="<?php echo esc_url($dustra_option['upload_logo_squre']['url']); ?>" class="logo regular" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <img src="<?php echo esc_url($dustra_option['upload_logo_squre']['url']); ?>" class="logo logo-responsive" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                    </a>
                    <?php endif;?>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-center',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>
            <?php
                if( !isset($dustra_option['sidemenu_position']) || $dustra_option['sidemenu_position'] == 1 ) :
            ?>
            <!-- Start Side Menu -->
            <div class="side">
                <a href="#" class="close-side"><i class="fas fa-times"></i></a>
                <div class="widget">
                    <?php
                    global $dustra_option;
                    if(!empty($dustra_option['sb_logo']['url'] )):?>
                        <img src="<?php echo esc_url($dustra_option['sb_logo']['url']); ?>" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                    <?php endif; ?>
                    <?php
                    global $dustra_option;
                    if(!empty($dustra_option['sb_content'] ) || !empty($dustra_option['sb_content'])):?>
                       <p><?php echo esc_html($dustra_option['sb_content']);?></p>
                    <?php endif; ?> 
                </div>
                <div class="widget address">
                    <div>
                        <ul>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_one_value'] )):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_one_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_one_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_two_value'] )):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_two_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_two_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_three_value'])):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_three_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_three_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="widget newsletter">
                    <?php
                        global $dustra_option;
                        if(!empty($dustra_option['sb_subscribe_text'])):
                    ?>
                    <h4 class="title"><?php echo esc_html($dustra_option['sb_subscribe_text']);?></h4>
                    <?php endif; ?>
                    <?php echo do_shortcode($dustra_option['sb_subscribe_sc']); ?>
                </div>
                <div class="widget social">
                    <ul class="link">
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_fb_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_fb_url']); ?>"><i class="fab fa-facebook-f"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_twitter_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_twitter_url']); ?>"><i class="fab fa-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_linkdin_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_linkdin_url']); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_pinterest_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_pinterest_url']); ?>"><i class="fab fa-pinterest"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_behance_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_behance_url']); ?>"><i class="fab fa-behance"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_dribbble_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_dribbble_url']); ?>"><i class="fab fa-dribbble"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_youtube_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_youtube_url']); ?>"><i class="fab fa-youtube"></i></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <!-- End Side Menu -->
            <?php endif; ?>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header -->
    <?php }elseif( $header_menu == '7' || $blog_header_style_seven ){ ?>
    <!-- Start Header Style Seven
    ============================================= -->
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar logo-less small-pad bg-dark white navbar-default navbar-sticky bootsnav">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <form role="search" method="get" action="<?php echo esc_url( home_url( '/' )); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <?php
                            if( !empty($dustra_option['header_search_button']) || $dustra_option['header_search_button'] == 1 ) :
                        ?>
                        <li class="search"><a href="#"><i class="ti-search"></i></a></li>
                        <?php endif;?>
                        <?php
                            if( !empty($dustra_option['sidemenu_position']) || $dustra_option['sidemenu_position'] == 1 ) :
                        ?>
                        <li class="side-menu">
                            <a href="#">
                                <span class="bar-1"></span>
                                <span class="bar-2"></span>
                                <span class="bar-3"></span>
                            </a>
                        </li>
                        <?php endif;?>
                        
                    </ul>
                </div>       
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                       <?php 
                            $page_color = get_post_meta( get_the_id(), 'page_color', true);
                            if($page_color == '2'){
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_yellow'] ) || !empty($dustra_option['upload_logo_yellow'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_yellow']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo-yellow.png' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?>
                            <?php }else{ 
                                global $dustra_option;
                                if(!empty($dustra_option['upload_logo_dark'] ) || !empty($dustra_option['upload_logo_dark'] )): ?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_dark']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php else: ?>
                                <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                                <?php endif; ?> 
                        <?php } ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-left',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

            <?php
                if( !empty($dustra_option['sidemenu_position']) || $dustra_option['sidemenu_position'] == 1 ) :
            ?>
            <!-- Start Side Menu -->
            <div class="side">
                <a href="#" class="close-side"><i class="fas fa-times"></i></a>
                <div class="widget">
                    <?php
                    global $dustra_option;
                    if(!empty($dustra_option['sb_logo']['url'] )):?>
                        <img src="<?php echo esc_url($dustra_option['sb_logo']['url']); ?>" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                    <?php endif; ?>
                    <?php
                    global $dustra_option;
                    if(!empty($dustra_option['sb_content'] ) || !empty($dustra_option['sb_content'])):?>
                       <p><?php echo esc_html($dustra_option['sb_content']);?></p>
                    <?php endif; ?> 
                </div>
                <div class="widget address">
                    <div>
                        <ul>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_one_value'] )):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_one_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_one_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_two_value'] )):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_two_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_two_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                            <?php
                                global $dustra_option;
                                if(!empty($dustra_option['sb_field_three_value'])):
                            ?>
                            <li>
                                <div class="content">
                                    <p><?php echo esc_html($dustra_option['sb_field_three_text']);?></p> 
                                    <strong><?php echo esc_html($dustra_option['sb_field_three_value']);?></strong>
                                </div>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div class="widget newsletter">
                    <?php
                        global $dustra_option;
                        if(!empty($dustra_option['sb_subscribe_text'])):
                    ?>
                    <h4 class="title"><?php echo esc_html($dustra_option['sb_subscribe_text']);?></h4>
                    <?php endif; ?>
                    <?php echo do_shortcode($dustra_option['sb_subscribe_sc']); ?>
                </div>
                <div class="widget social">
                    <ul class="link">
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_fb_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_fb_url']); ?>"><i class="fab fa-facebook-f"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_twitter_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_twitter_url']); ?>"><i class="fab fa-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_linkdin_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_linkdin_url']); ?>"><i class="fab fa-linkedin-in"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_pinterest_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_pinterest_url']); ?>"><i class="fab fa-pinterest"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_behance_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_behance_url']); ?>"><i class="fab fa-behance"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_dribbble_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_dribbble_url']); ?>"><i class="fab fa-dribbble"></i></a></li>
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['sb_youtube_url'])):
                        ?>
                            <li><a href="<?php echo esc_url($dustra_option['sb_youtube_url']); ?>"><i class="fab fa-youtube"></i></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <!-- End Side Menu -->
            <?php endif; ?>
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Header Style Seven -->
    <?php }elseif( $header_menu == '8' || $blog_header_style_eight ){ ?>
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default inc-top-bar navbar-fixed navbar-transparent white bootsnav">

            <div class="container">
                <?php global $dustra_option; if(!empty($dustra_option['header_eight_btn_text'])):?>
                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="button"><a href="<?php global $dustra_option; echo esc_url($dustra_option['header_eight_btn_link']); ?>"><?php echo esc_html($dustra_option['header_eight_btn_text']); ?></a></li>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->
                <?php endif;?>

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['upload_logo_dark']['url'] )):?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_dark']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <?php endif; ?>
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['upload_logo_eight']['url'] )):?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_eight']['url']); ?>" class="logo logo-scrolled" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <?php endif; ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
<?php }elseif( $header_menu == '9' || $blog_header_style_nine ){ ?>
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default bg-dark text-light navbar-sticky bootsnav">

            <div class="container-fluid">
                <?php if(!empty($dustra_option['header_quote_button_text'])): ?>
                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="button"><a href="<?php echo esc_url($dustra_option['header_quote_button_link']);?>"><?php echo esc_html($dustra_option['header_quote_button_text']);?><i class="fas fa-arrow-right"></i></a></li>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->
                <?php endif;?>

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                        <?php
                            global $dustra_option;
                            if(!empty($dustra_option['upload_logo_nine']['url'] )):?>
                                <img src="<?php echo esc_url($dustra_option['upload_logo_nine']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <?php endif; ?>
                    </a>


                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header> 
    <?php }else{?>
    <!-- Start Header Style Default -->    
    <header id="home">

        <!-- Start Navigation -->
        <nav class="navbar navbar-default navbar-sticky bootsnav">

            <!-- Start Top Search -->
            <div class="top-search">
                <div class="container">
                    <form role="search" method="get" action="<?php echo esc_url( home_url('/')); ?>">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-search"></i></span>
                            <input name="s" type="text" class="form-control"  value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php echo esc_attr__('Search','dustra'); ?>">
                            <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
                        </div>
                    </form>
                </div>
            </div>
            <!-- End Top Search -->

            <div class="container">

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                        <li class="search"><a href="<?php echo esc_url('#'); ?>"><i class="fa fa-search"></i></a></li>
                    </ul>
                </div>        
                <!-- End Atribute Navigation -->

                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
                        <i class="fa fa-bars"></i>
                    </button>
                    <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>">
                        <?php 
                        global $dustra_option;
                        if(!empty($dustra_option['upload_logo_light']['url'])): ?>
                            <img src="<?php echo esc_url($dustra_option['upload_logo_light']['url']); ?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                            <?php else: ?>
                            <img src="<?php echo get_template_directory_uri() .'/assets/img/logo.svg' ;?>" class="logo logo-display" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                        <?php endif; ?>
                    </a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <?php
                        wp_nav_menu(array(
                            'theme_location'  => 'onepage',
                            'container'       => 'ul',
                            'menu_class'      => 'nav navbar-nav navbar-right',
                            'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                            'walker'          => new WP_Bootstrap_Navwalker(),
                            'items_wrap'      => '<ul data-in="#" data-out="#" class="%2$s" id="%1$s">%3$s</ul>'
                        ));
                    ?>
                </div><!-- /.navbar-collapse -->
            </div>

        </nav>
        <!-- End Navigation -->

    </header>
    <!-- End Header Style Default -->       
    <?php
       }
    }
}
add_action( 'dustra_header_onepage', 'dustra_main_menu_onepage', 21 );
?>