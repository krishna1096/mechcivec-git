<?php 
    function dustra_topbar(){
        $topbar_style = get_post_meta( get_the_id(), 'topbar_style', true);

        if($topbar_style == 'style_one'){
            dustra_topbar_style_one();
        }elseif($topbar_style == 'style_two'){
            dustra_topbar_style_two();
        }elseif($topbar_style == 'style_three'){
            dustra_topbar_style_three();
        }else{
            dustra_topbar_style_one();
        }
    }

    function dustra_topbar_style_one(){
    global $dustra_option;
    ?>
    <!-- Start Header Top One
    ============================================= -->
    <div class="top-bar-area bg-dark text-light">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-3 shape">
                    <ul class="social">
                        <?php if(!empty($dustra_option['fb_url'])) :?>
                            <li class="facebook">
                               <a target="_blank" href="<?php echo esc_html($dustra_option['fb_url']); ?>"><i class="fab fa-facebook-f"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['twitter_url'])) :?>
                            <li class="twitter">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['twitter_url']); ?>"><i class="fab fa-twitter"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['pinterest_url'])) :?>
                            <li class="pinterest">
                                 <a target="_blank" href="<?php echo esc_html($dustra_option['pinterest_url']); ?>"><i class="fab fa-pinterest"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['linkdin_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['linkdin_url']); ?>"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['dribbble_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['dribbble_url']); ?>"><i class="fab fa-dribbble"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['behance_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['behance_url']); ?>"><i class="fab fa-behance"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['youtube_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['youtube_url']); ?>"><i class="fab fa-youtube"></i></a>
                            </li>
                        <?php endif;?>
                    </ul>
                </div>
                <div class="col-lg-9 info float-right text-right">
                    <div class="info box">
                        <ul class="list">
                            <?php if(!empty($dustra_option['address'])): ?>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <?php 
                                global $dustra_option;
                                if(!empty($dustra_option['address'])):
                                    echo esc_html($dustra_option['address']);
                                endif; 
                                ?>
                            </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['email'])): ?>
                                <li>
                                    <i class="fas fa-envelope-open"></i>
                                    <a href="mailto:<?php echo esc_attr($dustra_option['email']); ?>"><?php echo esc_html($dustra_option['email']); ?></a>
                                </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['phone'])): ?>
                            <li>
                                <i class="fas fa-phone"></i>
                                <?php 
                                if(!empty($dustra_option['phone'])): ?>    
                                    <a href="tel:<?php echo esc_attr($dustra_option['phone']); ?>"><?php echo esc_html($dustra_option['phone']); ?></a>
                                <?php endif; ?>
                            </li>
                            <?php endif;?>
                        </ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top One -->
    <?php }


    function dustra_topbar_style_two(){
    global $dustra_option;
    ?>
    <!-- Start Header Top Two
    ============================================= -->
    <div class="topbar-style-three">
        <div class="container">
            <div class="row">
                <div class="col-md-4 logo">
                    <?php if(!empty($dustra_option['topbar_logo']['url'])):?>
                    <a href="<?php echo esc_url(home_url('/')); ?>">
                        <img src="<?php echo esc_url($dustra_option['topbar_logo']['url']); ?>" class="logo" alt="<?php echo esc_attr__( 'dustra', 'dustra' ); ?>">
                    </a>
                    <?php endif;?>
                </div>
                <div class="col-md-8 address-info text-right">
                    <div class="info box">
                        <ul>
                            <?php if(!empty($dustra_option['address'])): ?>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-map-marker-alt"></i>
                                </div>
                                <div class="info">
                                    <span><?php echo esc_html__("Address",'dustra');?></span> <?php echo esc_html($dustra_option['address']); ?>
                                </div> 
                            </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['email'])): ?>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-envelope-open-text"></i>
                                </div>
                                <div class="info">
                                    <span><?php echo esc_html__("Email",'dustra');?></span><?php echo esc_html($dustra_option['email']); ?>
                                </div>
                            </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['phone'])): ?>
                            <li>
                                <div class="icon">
                                    <i class="fas fa-headphones-alt"></i>
                                </div>
                                <div class="info">
                                    <span><?php echo esc_html__("Phone",'dustra');?></span> <?php echo esc_html($dustra_option['phone']); ?>
                                </div>
                            </li>
                            <?php endif;?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top Two -->
    <?php }

    function dustra_topbar_style_three(){
    global $dustra_option;
    ?>
    <!-- Start Header Top One
    ============================================= -->
    <div class="top-bar-area bg-dark dark-all text-light">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-3 shape">
                    <ul class="social">
                        <?php if(!empty($dustra_option['fb_url'])) :?>
                            <li class="facebook">
                               <a target="_blank" href="<?php echo esc_html($dustra_option['fb_url']); ?>"><i class="fab fa-facebook-f"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['twitter_url'])) :?>
                            <li class="twitter">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['twitter_url']); ?>"><i class="fab fa-twitter"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['pinterest_url'])) :?>
                            <li class="pinterest">
                                 <a target="_blank" href="<?php echo esc_html($dustra_option['pinterest_url']); ?>"><i class="fab fa-pinterest"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['linkdin_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['linkdin_url']); ?>"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['dribbble_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['dribbble_url']); ?>"><i class="fab fa-dribbble"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['behance_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['behance_url']); ?>"><i class="fab fa-behance"></i></a>
                            </li>
                        <?php endif;?>
                        <?php if(!empty($dustra_option['youtube_url'])) :?>
                            <li class="linkedin">
                                <a target="_blank" href="<?php echo esc_html($dustra_option['youtube_url']); ?>"><i class="fab fa-youtube"></i></a>
                            </li>
                        <?php endif;?>
                    </ul>
                </div>
                <div class="col-lg-9 info float-right text-right">
                    <div class="info box">
                        <ul class="list">
                            <?php if(!empty($dustra_option['address'])): ?>
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <?php 
                                global $dustra_option;
                                if(!empty($dustra_option['address'])):
                                    echo esc_html($dustra_option['address']);
                                endif; 
                                ?>
                            </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['email'])): ?>
                                <li>
                                    <i class="fas fa-envelope-open"></i>
                                    <a href="mailto:<?php echo esc_attr($dustra_option['email']); ?>"><?php echo esc_html($dustra_option['email']); ?></a>
                                </li>
                            <?php endif;?>
                            <?php if(!empty($dustra_option['phone'])): ?>
                            <li>
                                <i class="fas fa-phone"></i>
                                <?php 
                                if(!empty($dustra_option['phone'])): ?>    
                                    <a href="tel:<?php echo esc_attr($dustra_option['phone']); ?>"><?php echo esc_html($dustra_option['phone']); ?></a>
                                <?php endif; ?>
                            </li>
                            <?php endif;?>
                        </ul>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Header Top One -->
    <?php }
    ?>