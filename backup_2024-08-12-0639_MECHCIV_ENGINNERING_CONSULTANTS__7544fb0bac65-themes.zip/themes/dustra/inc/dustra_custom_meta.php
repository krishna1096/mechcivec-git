<?php
function dustra_service_info(){

	$cmb = new_cmb2_box(array(
     'id'           =>'_service_meta',
     'title'        => esc_html__('Additionl fields for service post type','dustra'),
     'object_types' =>array('dustra-service'),
    ));

    $cmb->add_field( array(
        'name'          =>  esc_html__('Extra Title', 'dustra'),
        'id'            => '_extra_title',
        'type'          => 'text',
    ));

	$cmb->add_field( array(
        'name'          => esc_html__('Icon Type','dustra'),
        'desc'          => esc_html__('Select an option form the dropdown menu','dustra'),
        'id'            => 'icon-type',
        'type'          => 'select',
        'default'       => 'custom',
        'options'       => array(
            'custom'            => esc_html__('Custom Icon','dustra'),
            'flat_icon'         => esc_html__('Flat Icon','dustra'),
            'icofont'         => esc_html__('IcoFont','dustra'),
        ),
    ) );

    $cmb->add_field( array(
        'name'          => esc_html__('Custom Icon','dustra'),
        'desc'          => esc_html__('Upload a custom Icon or enter s URL for this service.','dustra'),
        'id'            => 'custom_icon',
        'type'          => 'file',
        'attributes'    => array(
            'required'                  => true,
            'data-conditional-id'       => 'icon-type',
            'data-conditional-value'    => 'custom',
        ),
        'allow'         => array( 'url', 'attachment' ),
        'text'          => array(
            'add_upload_file_text'      => esc_html__('Add Icon','dustra'),
        ),
        'query_args'    => array(
            'type'                      => array('image/gif', 'image/jpeg', 'image/png'),
        ),
        'preview_size'  => array(100,100),
    ));

    $cmb->add_field( array(
        'name' => 'IcoFont',
        'id'   => 'icofont',
        'type' => 'text',
        'attributes'        => array(
            'required'               => true,
            'data-conditional-id'    => 'icon-type',
            'data-conditional-value' => 'icofont',
        ),
        'desc' => esc_html__( 'Just go to here "https://icofont.com/icons" and copy the icon name.', "dustra" ),
        'default' => 'icofont-vehicle-trucktor',
    ) );


    $cmb->add_field( array(
        'name'          => esc_html__('Flat Icon','dustra'),
        'desc'          => esc_html__('Select an icon name form the dropdown menu','dustra'),
        'id'            => 's_icon',
        'type'          => 'select',
        'attributes'        => array(
            'required'               => true,
            'data-conditional-id'    => 'icon-type',
            'data-conditional-value' => 'flat_icon',
        ),
        'default'          => 'custom',
        'options_cb' => 'dustra_flat_icon_options',
    ));
    

    $cmb->add_field( array(
        'id'            => '_service_meta',
        'type'          => 'group',
        'options'       => array(
            'group_title'       => __( 'Document {#}', 'dustra' ),
            'add_button'        => __( 'Add Document', 'dustra' ),
            'remove_button'     => __( 'Remove Document', 'dustra' ),
            'sortable'          => true,
            'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'dustra' )
        ),
        'limit'         => 4,
    ));
    
    $cmb->add_group_field( '_service_meta', array(
        'name'          =>  esc_html__('Title', 'dustra'),
        'id'            => '_accordion-title',
        'type'          => 'text',
    ));

    $cmb->add_group_field( '_service_meta', array(
        'name'          => esc_html__('Attachment :','dustra'),
        'desc'          => esc_html__('Add an attachmnet.', 'dustra'),
        'id'            => '_pdf_attachment',
        'type'          => 'file',
        'options'       => array(
            'url'           => false, // Hide the text input for the url
        ),
        'text'          => array(
            'add_upload_file_text' => esc_html__('Add File','dustra')
        ),
        'query_args'    => array(
            'type'          => 'application/pdf',
        ),
    ) );
}

add_action( 'cmb2_admin_init', 'dustra_service_info' );

function dustra_portfolio_info(){

	$cmb =new_cmb2_box(array(
     'id'          =>'portfolio_info',
     'title'       =>esc_html('Portfolio Info','dustra'),
     'object_types'=>array('dustra-portfolio'),
	));

    $cmb->add_field( array(
        'name' => 'Launch Date',
        'id'   => 'launch_date',
        'type' => 'text_date',
    ) );

    $cmb->add_field( array(
        'id'            => '_accordion-meta',
        'type'          => 'group',
        'options'       => array(
            'group_title'       => __( 'Accordion value {#}', 'dustra' ),
            'add_button'        => __( 'Add another accordion value', 'dustra' ),
            'remove_button'     => __( 'Remove accordion value', 'dustra' ),
            'sortable'          => true,
            'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'dustra' )
        ),
        'limit'         => 4,
    ));

    $cmb->add_group_field( '_accordion-meta', array(
        'name'          =>  esc_html__('Title', 'dustra'),
        'id'            => '_accordion-title',
        'type'          => 'text',
    ));

    $cmb->add_group_field( '_accordion-meta', array(
        'name'          =>  esc_html__('Description', 'dustra'),
        'id'            => '_accordion-desc',
        'type'          => 'text',
    ));

    $cmb->add_field( array(
        'name'    => 'Extra Content',
        'desc'    => 'field description (optional)',
        'id'      => 'portfolio_content',
        'type'    => 'wysiwyg',
        'options' => array(),
    ) );

}

add_action( 'cmb2_admin_init', 'dustra_portfolio_info' );

function dustra_team_info(){

    $cmb =new_cmb2_box(array(
     'id'          =>'team_info',
     'title'       =>esc_html('Team Information','dustra'),
     'object_types'=>array('dustra-team'),
    ));

    $cmb->add_field( array(
    'name'    => esc_html__('Designation', 'dustra'),
    'id'      => '_designation',
    'type'    => 'text',
    ) );

    $cmb->add_field( array(
        'name'          =>  esc_html__('Email', 'dustra'),
        'id'            => '_email',
        'type'          => 'text',
    ));
    $cmb->add_field( array(
        'name'          =>  esc_html__('Phone', 'dustra'),
        'id'            => '_phone',
        'type'          => 'text',
    ));
    $cmb->add_field( array(
        'name'          =>  esc_html__('Conatct Link', 'dustra'),
        'id'            => '_contact',
        'type'          => 'text',
    ));

    $cmb->add_field( array(
        'name'          =>  esc_html__('Facebook Link', 'dustra'),
        'id'            => '_facebook',
        'type'          => 'text',
    ));

    $cmb->add_field( array(
        'name'          =>  esc_html__('Twitter Link', 'dustra'),
        'id'            => '_twitter',
        'type'          => 'text',
    ));

    $cmb->add_field( array(
        'name'          =>  esc_html__('Youtube Link', 'dustra'),
        'id'            => '_youtube',
        'type'          => 'text',
    ));

    $cmb->add_field( array(
        'name'    => 'Left Content',
        'desc'    => 'field description (optional)',
        'id'      => 'team_content',
        'type'    => 'wysiwyg',
        'options' => array(),
    ) );

    $cmb->add_field( array(
        'id'            => '_team-meta',
        'type'          => 'group',
        'options'       => array(
            'group_title'       => __( 'Accordion value {#}', 'dustra' ),
            'add_button'        => __( 'Add another accordion value', 'dustra' ),
            'remove_button'     => __( 'Remove accordion value', 'dustra' ),
            'sortable'          => true,
            'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'dustra' )
        ),
        'limit'         => 4,
    ));

    $cmb->add_group_field( '_team-meta', array(
        'name'          =>  esc_html__('Title', 'dustra'),
        'id'            => '_accordion-title',
        'type'          => 'text',
    ));

    $cmb->add_group_field( '_team-meta', array(
        'name'          =>  esc_html__('Number', 'dustra'),
        'id'            => '_accordian-number',
        'type'          => 'text',
    ));

    
}

add_action( 'cmb2_admin_init', 'dustra_team_info' );

function dustra_page_meta_info(){

	$cmb =new_cmb2_box(array(
     'id'          =>'dustra_page_meta',
     'title'       =>esc_html('Dustra Page Meta','dustra'),
     'object_types'=>array('page'),

	));


    $cmb->add_field(array(
		'name'    => esc_html('Topbar Position','dustra'),
		'id'      => '_topbar_position',
		'type'    => 'radio_inline',
		'options' => array(
			'1' => __( 'Hide', 'dustra' ),
			'2'   => __( 'Show', 'dustra' ),
		),
		'default' => '1',
        )
    );

    $cmb->add_field(array (
		'name' => esc_html__( 'Topbar Style', 'dustra' ),
		'id' => 'topbar_style',
		'type' => 'select',
		'default' => 'style_one',
		'show_option_none' => false,
		'options' => array(
			'style_one' => esc_html__( 'Style One', 'dustra' ),
            'style_two' => esc_html__( 'Style Two', 'dustra' ),
            'style_three' => esc_html__( 'Style Three', 'dustra' ),
		),
	   )
    );
    $cmb->add_field(array (
        'name' => esc_html__( 'Page Variant', 'dustra' ),
        'id' => 'page_color',
        'type' => 'select',
        'default' => '1',
        'show_option_none' => false,
        'options' => array(
            '1' => esc_html__( 'Default', 'dustra' ),
            '2' => esc_html__( 'Yellow', 'dustra' ),
            '3' => esc_html__( 'Red', 'dustra' ),
            '4' => esc_html__('It-solution','dustra'),
            '5' => esc_html__('Solor Energy','dustra'),
        ),
       )
    );

    $cmb->add_field(array (
		'name' => esc_html__( 'Header Style', 'dustra' ),
		'id' => 'header_style',
		'type' => 'select',
		'default' => '1',
		'show_option_none' => false,
		'options' => array(
			'1' => esc_html__( 'Style One', 'dustra' ),
			'2' => esc_html__( 'Style Two', 'dustra' ),
            '3' => esc_html__( 'Style Three', 'dustra' ),
            '4' => esc_html__( 'Style Four', 'dustra' ),
            '5' => esc_html__( 'Style Five', 'dustra' ),
            '6' => esc_html__( 'Style Six', 'dustra' ),
            '7' => esc_html__( 'Style Seven', 'dustra' ),
            '8' => esc_html__( 'Style Eight', 'dustra' ),
            '9' => esc_html__( 'Style Nine', 'dustra' ),
		),
	   )
    );

}
add_action( 'cmb2_admin_init', 'dustra_page_meta_info' );

add_action( 'cmb2_admin_init', 'dustra_flat_icon_options' );
    function dustra_flat_icon_options() {
        return 
        array(
        'flaticon-crane' => 'Flaticon-crane',
        'flaticon-excavator' => 'Excavator',
        'flaticon-machinery' => 'Machinery',
        'flaticon-engineer' => 'Engineer',
        'flaticon-worker' => 'Worker',
        'flaticon-engineer-1' => 'Engineer-1',
        'flaticon-engineer-2' => 'Engineer-2',
        'flaticon-factory' => 'Factory',
        'flaticon-power-plant' => 'Power-plant',
        'flaticon-factory-1' => 'Factory-1',
        'flaticon-factory-2' => 'Factory-2',
        'flaticon-factory-3' => 'Factory-3',
        'flaticon-helmet' => 'Helmet',
        'flaticon-antivirus' => 'Antivirus',
        'flaticon-engineer-3' => 'Engineer-3',
        'flaticon-tripod' => 'Tripod',
        'flaticon-milling-machine' => 'Milling-machine',
        'flaticon-solar-panel' => 'Solar-panel',
        'flaticon-creativity' => 'Creativity',
        'flaticon-house' => 'House',
        'flaticon-wind-energy' => 'Wind-energy',
        'flaticon-building' => 'Building',
        'flaticon-lighthouse' => 'Lighthouse',
        'flaticon-system' => 'System',
        'flaticon-turbo' => 'Turbo',
        'flaticon-turbine' => 'Turbine',
        'flaticon-water-pump' => 'Water-pump',
        'flaticon-ruler' => 'Ruler',
        'flaticon-process' => 'Process',
        'flaticon-puzzle' => 'Puzzle',
        'flaticon-tablet' => 'Tablet',
        'flaticon-growth' => 'Growth',
        'flaticon-telephone' => 'Telephone',
        'flaticon-call' => 'Call',
        'flaticon-call-1' => 'Call-1',
        'flaticon-email' => 'Email',
        'flaticon-email-1' => 'Email-1',
        'flaticon-location' => 'Location',
        'flaticon-route' => 'route',
        'flaticon-bridge' => 'Bridge',
        'flaticon-golden-gate' => 'golden-gate',
        'flaticon-bridge-1' => 'Bridge-1',
        'flaticon-harvest' => 'Harvest',
        'flaticon-tractor' => 'Tractor',
        'flaticon-tractor-1' => 'Tractor-1',
        );
    }

 ?>