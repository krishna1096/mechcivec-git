<?php
/**
 * The template for displaying the header
 *
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Dustra
 */
?>
<!DOCTYPE html>
<html <?php language_attributes();?> >

<head>
    <!-- ========== Meta Tags ========== -->
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="dustra - Factory, Industrial & Construction Template">
    <!-- ========== Favicon Icon ========== -->
    <?php 
        $def_fav_icon = get_template_directory_uri() .'/assets/img/favicon.png'; ?>
        <link rel="shortcut icon" href="<?php global $dustra_option; if(isset($dustra_option['favicon'])){ echo esc_url($dustra_option['favicon']['url']);} else { echo esc_url( $def_fav_icon );} 
    ?>">
    <?php wp_head(); $page_color = get_post_meta( get_the_id(), 'page_color', true); ?>
</head>
<body <?php body_class(); ?>>
    <?php wp_body_open(); ?>
    <?php
        $topbar_position = get_post_meta( get_the_id(), '_topbar_position', true);
        if( class_exists( 'ReduxFramework' )){
            global $dustra_option; 
            $blog_topbar_postion = $dustra_option['blog_topbar_position'];
            if(get_post_type() === 'post' && $dustra_option['blog_topbar_position'] == '1'){
                dustra_topbar();
            }elseif($topbar_position == '2'){
                dustra_topbar();
            }
        }elseif($topbar_position == '2'){
            dustra_topbar();
        }   
    ?>
    <!-- MainMenu Start -->
    <?php do_action( 'dustra_header_onepage'); ?>
    <!-- MainMenu Ends -->