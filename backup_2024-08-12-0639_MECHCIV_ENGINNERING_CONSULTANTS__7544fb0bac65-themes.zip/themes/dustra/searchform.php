<?php
/**
 * Template for displaying search forms
 *
 * @package  Dustra
 * @since    1.0
 */
?>
<div class="sidebar-item search">
    <div class="sidebar-info">
        <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="text" class="form-control"
	       placeholder="<?php echo esc_attr_x( 'Search&hellip;', 'placeholder', 'dustra' ); ?>"
	       value="<?php echo get_search_query() ?>" name="s"
	       title="<?php echo esc_attr_x( 'Search for:', 'label', 'dustra' ); ?>"/>
            <button type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>
</div>
