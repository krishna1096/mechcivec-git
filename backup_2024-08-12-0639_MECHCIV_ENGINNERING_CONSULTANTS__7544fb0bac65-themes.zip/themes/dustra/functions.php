<?php
/**
 * Dustra functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Dustra
 */
if ( ! function_exists( 'dustra_basic_function' ) ) :

    require_once( get_theme_file_path( "/lib/class-tgm-plugin-activation.php" ) );
    require_once get_template_directory() . '/inc/dustra_navwalker.php';

    if(class_exists('CMB2_Bootstrap_260')){
        require_once(dirname(__FILE__) . '/inc/init.php');
    }
    if(file_exists(dirname(__FILE__) . '/inc/dustra_custom_meta.php')){
        require_once(dirname(__FILE__) . '/inc/dustra_custom_meta.php');
    }
    if(file_exists(dirname(__FILE__) . '/simple/dustra-config.php')){
        require_once(dirname(__FILE__) . '/simple/dustra-config.php');
    }
    require_once get_template_directory() . '/simple/color.php';

    function dustra_basic_function() {
        load_theme_textdomain( 'dustra', get_template_directory() . '/languages');
        add_theme_support( 'automatic-feed-links' );
        add_theme_support( 'editor-style' );
        add_theme_support( 'post-thumbnails' );
        add_theme_support( 'title-tag' );

        /*
        * Switch default core markup for search form, comment form, and comments
        * to output valid HTML5.
        */
        add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

        register_nav_menus( array(
            'primary' => esc_html__( 'Primary Menu', 'dustra' ),
        ) );
        
        if( class_exists( 'ReduxFramework' ) ){
            register_nav_menus( array(
                'footer-menu' => esc_html__( 'Footer Copyright Menu', 'dustra' ),
            ) );
            register_nav_menus( array(
                'onepage' => esc_html__( 'One Page Menu', 'dustra' ),
            ) );
        }

        add_image_size( 'dustra_700x800', 700,800,true);
        add_image_size( 'dustra_800x800', 800,800,true);
        add_image_size( 'dustra_1230x574', 1230, 574, true );
        add_image_size( 'dustra_770x361', 770, 361, true );
        add_image_size( 'dustra_945x441', 945, 441, true );
        add_image_size( 'dustra_850x450', 850, 450, true );
        add_image_size( 'dustra_800x600', 800, 600, true );
        add_image_size( 'dustra_800x1050', 800, 1050, true );

        add_theme_support( 'post-formats', array(
            'aside',
            'gallery',
            'link',
            'image',
            'quote',
            'video',
            'audio',
        ) );
        /**
         * Set the content width in pixels, based on the theme's design and stylesheet.
         *
         * Priority 0 to make it available to lower priority callbacks.
         *
         * @global int $content_width
         */
        function dustra_content_width() {
            // This variable is intended to be overruled from themes.
            // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
            // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
            $GLOBALS['content_width'] = apply_filters( 'dustra_content_width', 640 );
        }
        add_action( 'after_setup_theme', 'dustra_content_width', 0 );
    }
    add_action( 'after_setup_theme', 'dustra_basic_function' );
    endif;

   

    function dustra_google_fonts() {
        $font_url = '';

        /*
        Translators: If there are characters in your language that are not supported
        by chosen font(s), translate this to 'off'. Do not translate into your own language.
         */
        if ( 'off' !== _x( 'on', 'Google font: on or off', 'dustra' ) ) {
            $font_url =  'https://fonts.googleapis.com/css2?family=Yantramanav:wght@100;300;400;500;700;900&display=swap';
        }
        return $font_url;
    }

    function dustra_add_script() {
        wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', null, "1.0" );
        wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', null, "1.0" );
        wp_enqueue_style( 'flaticon', get_template_directory_uri() . '/assets/css/flaticon-set.css', null, "1.0" );
        wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.css', null, "1.0" );
        wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.min.css' );
        wp_enqueue_style( 'owl-theme-default', get_template_directory_uri() . '/assets/css/owl.theme.default.min.css');
        wp_enqueue_style( 'animate', get_template_directory_uri() . '/assets/css/animate.css', null, "1.0" );
        wp_enqueue_style( 'themify-icons', get_template_directory_uri() . '/assets/css/themify-icons.css', null, "1.0" );
        wp_enqueue_style( 'bootsnav', get_template_directory_uri() . '/assets/css/bootsnav.css', null, "1.0" );
        wp_enqueue_style( 'icofont', get_template_directory_uri() . '/assets/css/icofont.min.css', null, "1.0" );
        wp_enqueue_style( 'dustra-core', get_template_directory_uri() . '/assets/css/dustra-core.css', null, "1.0" );
        wp_enqueue_style( 'dustra-unit', get_template_directory_uri() . '/assets/css/dustra-unit.css', null, "1.0" );
        wp_enqueue_style( 'dustra-responsive', get_template_directory_uri() . '/assets/css/dustra-responsive.css', null, "1.0");
        wp_enqueue_style( 'dustra-fonts', dustra_google_fonts() );
        wp_enqueue_style( 'dustra-style', get_stylesheet_uri() );


        wp_enqueue_script( 'popper-min', get_template_directory_uri() . '/assets/js/popper.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'equal-height', get_template_directory_uri() . '/assets/js/equal-height.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'jquery-appear', get_template_directory_uri() . '/assets/js/jquery.appear.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'easing-min', get_template_directory_uri() . '/assets/js/jquery.easing.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'jquery-magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'modernizr', get_template_directory_uri() . '/assets/js/modernizr.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'wow', get_template_directory_uri() . '/assets/js/wow.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'progress-bar', get_template_directory_uri() . '/assets/js/progress-bar.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'isotope-pkgd', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'imagesloaded-pkgd', get_template_directory_uri() . '/assets/js/imagesloaded.pkgd.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'nice-select-js', get_template_directory_uri() . '/assets/js/jquery.nice-select.min.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'count-to', get_template_directory_uri() . '/assets/js/count-to.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'gsap', get_template_directory_uri() . '/assets/js/gsap.min.js', array( 'jquery' ), false, true );
         wp_enqueue_script( 'simpleloadmore', get_template_directory_uri() . '/assets/js/jquery.simpleLoadMore.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'mousemove', get_template_directory_uri() . '/assets/js/jquery.MouseMove.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'bootsnav', get_template_directory_uri() . '/assets/js/bootsnav.js', array( 'jquery' ), false, true );
        wp_enqueue_script( 'dustra-main-script', get_template_directory_uri() . '/assets/js/main.js', array( 'jquery' ), false, true );
        
        if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
            wp_enqueue_script( 'comment-reply' );
          }
        }

    add_action('wp_enqueue_scripts', 'dustra_add_script' );

    require_once get_template_directory() . '/inc/dustra_helper.php';
    require_once get_template_directory() . '/inc/dustra_topbar.php';
    require_once get_template_directory() . '/inc/dustra_header_menu.php';
    require_once get_template_directory() . '/inc/dustra_header_menu_onepage.php';
    require_once get_template_directory() . '/inc/dustra_plugin_activation.php';
    require_once get_template_directory() . '/inc/dustra_breadcumb.php';
    require_once get_template_directory() . '/inc/dustra_demo_config.php';
?>