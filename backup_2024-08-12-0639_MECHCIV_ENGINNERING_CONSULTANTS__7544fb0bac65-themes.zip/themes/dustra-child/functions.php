<?php
/**
*
* @Packge      Dustra
* @Author      validthemes
* @Author URL  https://themeforest.net/user/validthemes/portfolio
* @version     1.5.3
*
*/
/**
 * Enqueue style of child theme
 */
if ( !function_exists( 'dustra_chld_theme_cfg_parent' ) ):
function dustra_chld_theme_cfg_parent(){
	$parent_style = 'dustra-parent-style'; 
	wp_enqueue_style($parent_style, get_parent_theme_file_uri("/style.css"));
	wp_enqueue_style( "dustra-child-style",
	        get_stylesheet_directory_uri() . '/style.css',
	        array( $parent_style ),
	        wp_get_theme()->get('Version')
	    );
}
endif;
add_action( 'wp_enqueue_scripts', 'dustra_chld_theme_cfg_parent');
?>